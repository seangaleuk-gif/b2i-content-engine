// ── Canonical Final Article Policy ──
// One shared definition of all final article postconditions.
// Use `analyzeFinalArticle()` in every validation stage so no two stages
// compute the same metric independently with different implementations.

import {
  extractReadableText,
  extractH2Texts,
  extractParagraphTexts,
  countExactPhrase,
  countReadableWords,
  countSentences,
  getFirstNReadableWords,
} from "@/lib/seo/seo-text-utils";
import { keyphraseRangeForWordCount, MAX_SENTENCES_PER_PARAGRAPH } from "@/lib/services/generation-constants";

// ── Policy ──

export interface FinalArticlePolicy {
  wordCountMin: number;
  wordCountMax: number;
  keyphraseCountMin: number;
  keyphraseCountMax: number;
  titleMinLength: number;
  titleMaxLength: number;
  requireKeyphraseInFirst100Words: boolean;
  maxSentencesPerParagraph: number;
  internalLinkMin: number;
  internalLinkMax: number;
  requireLanguageSwitcher: boolean;
  requireFaqSchema: boolean;
  requireCtaBlock: boolean;
}

/** Build the canonical policy from a requested word count. */
export function buildPolicy(
  requestedWordCount: number,
  wordCountMin?: number,
  wordCountMax?: number,
): FinalArticlePolicy {
  const kpRange = keyphraseRangeForWordCount(requestedWordCount);
  return {
    wordCountMin: wordCountMin ?? requestedWordCount, // caller should provide wordMin from wordCountRange()
    wordCountMax: wordCountMax ?? requestedWordCount,
    keyphraseCountMin: kpRange.min,
    keyphraseCountMax: kpRange.max,
    titleMinLength: 40,
    titleMaxLength: 70,
    requireKeyphraseInFirst100Words: true,
    maxSentencesPerParagraph: MAX_SENTENCES_PER_PARAGRAPH,
    internalLinkMin: 3,
    internalLinkMax: 5,
    requireLanguageSwitcher: true,
    requireFaqSchema: false, // FAQ schema validated separately
    requireCtaBlock: false, // CTA validated structurally
  };
}

// ── Unified metrics ──

export interface FinalArticleMetrics {
  readableWordCount: number;
  exactKeyphraseCount: number;
  keyphraseDensity: number;
  exactKeyphraseInH2: boolean;
  longParagraphCount: number;
  keyphraseInFirst100Words: boolean;
  uniqueInternalLinkCount: number;
}

/** Count unique internal editorial link destinations excluding switcher / CTA / schema. */
export function countUniqueInternalLinks(html: string): number {
  const stripped = html.replace(/<script[\s\S]*?<\/script>/gi, "");
  const hrefRe = /<a\b[^>]*href="([^"]*)"[^>]*>/gi;
  const seen = new Set<string>();
  let m: RegExpExecArray | null;
  while ((m = hrefRe.exec(stripped)) !== null) {
    const href = m[1];
    if (!href.startsWith("/")) continue;
    if (href.startsWith("/#")) continue;
    if (/-zh\b/i.test(href)) continue;
    if (/signup/i.test(href)) continue;
    if (/auth\//i.test(href)) continue;
    seen.add(href.replace(/\/$/, ""));
  }
  return seen.size;
}

// ── Canonical analyzer ──

/** Compute all final article metrics from HTML. The single shared implementation. */
export function analyzeFinalArticle(
  html: string,
  keyphrase: string,
): FinalArticleMetrics {
  const readableText = extractReadableText(html);
  const h2Texts = extractH2Texts(html);
  const paraTexts = extractParagraphTexts(html);
  const kpLower = keyphrase.toLowerCase().trim();

  const first100 = getFirstNReadableWords(html, 100).toLowerCase();

  return {
    readableWordCount: countReadableWords(html),
    exactKeyphraseCount: countExactPhrase(readableText, keyphrase),
    keyphraseDensity: 0, // computed separately when needed
    exactKeyphraseInH2: h2Texts.some((h) => h.toLowerCase().includes(kpLower)),
    longParagraphCount: paraTexts.filter((t) => countSentences(t) > MAX_SENTENCES_PER_PARAGRAPH).length,
    keyphraseInFirst100Words: first100.includes(kpLower),
    uniqueInternalLinkCount: countUniqueInternalLinks(html),
  };
}

/** Check whether metrics satisfy the policy. Returns the pass/fail and reasons. */
export function evaluatePolicy(
  metrics: FinalArticleMetrics,
  policy: FinalArticlePolicy,
): { passed: boolean; reasons: string[] } {
  const reasons: string[] = [];

  const wcOk = metrics.readableWordCount >= policy.wordCountMin;
  const kpOk = metrics.exactKeyphraseCount >= policy.keyphraseCountMin
    && metrics.exactKeyphraseCount <= policy.keyphraseCountMax;
  const h2Ok = metrics.exactKeyphraseInH2;
  const parasOk = metrics.longParagraphCount === 0;
  const first100Ok = !policy.requireKeyphraseInFirst100Words || metrics.keyphraseInFirst100Words;
  const linksOk = metrics.uniqueInternalLinkCount >= policy.internalLinkMin
    && metrics.uniqueInternalLinkCount <= policy.internalLinkMax;

  if (!wcOk) reasons.push(`wc=${metrics.readableWordCount}/${policy.wordCountMin}`);
  if (!kpOk) reasons.push(`kp=${metrics.exactKeyphraseCount}/${policy.keyphraseCountMin}-${policy.keyphraseCountMax}`);
  if (!h2Ok) reasons.push("no H2 keyphrase");
  if (!parasOk) reasons.push(`long paragraphs=${metrics.longParagraphCount}`);
  if (!first100Ok) reasons.push("keyphrase not in first 100 words");
  if (!linksOk) reasons.push(`internal links=${metrics.uniqueInternalLinkCount}`);

  return {
    passed: wcOk && kpOk && h2Ok && parasOk && first100Ok && linksOk,
    reasons,
  };
}
