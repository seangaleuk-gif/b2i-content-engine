import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/services/auth";
import {
  projectRepository,
  researchRepository,
  knowledgeRepository,
  promptSectionRepository,
  blogVersionRepository,
  aiLogRepository,
  generationAnalyticsRepository,
} from "@/lib/repositories";
import { buildAnalyticsRecord } from "@/lib/services/generation-analytics";
import { buildBlogPrompt, STAGE_SYSTEM_PROMPTS } from "@/lib/services/prompt-builder";
import { getCompiledBundle } from "@/lib/services/prompt-compiler";
import { createDeepSeekClient } from "@/lib/services/deepseek";
import { countReadableWords, robustJsonParse, repairMetaDescription, containsExactPhrase, splitLongParagraphs } from "@/lib/services/text-utils";
import { META_MIN, META_MAX, DEFAULT_WORD_COUNT, WORD_ALLOCATION, keyphraseTarget, keyphraseRangeForWordCount, keyphrasePreferredTarget, allocateComponentKeyphraseBudgets, buildComponentBudgetPrompt, type ComponentKeyphraseBudget, GENERATION_WORD_BUFFER, MAX_SECTION_EXPANSIONS, MAX_SENTENCES_PER_PARAGRAPH, wordCountRange, SEO_TITLE_MIN, SEO_TITLE_MAX } from "@/lib/services/generation-constants";
import { runComponentRegeneration, regenerateIntroduction, regenerateSection, regenerateConclusion, type GenContext } from "@/lib/services/component-regenerator";
import { buildGenerationReport, formatReport } from "@/lib/services/quality-scorer";
import { GenerationTelemetry, type AiCallRecord } from "@/lib/services/generation-telemetry";
import { validateContent, type ContentValidationReport } from "@/lib/services/content-validator";
import { ensureLanguageSwitcher, pairedSlugs, insertExternalResearchLinks, sanitizeSectionUrls, deduplicateEditorialExternalLinks } from "@/lib/services/article-postprocessors";
import { expandToMinimum, trimToMaximum, normalizeParagraphs } from "@/lib/services/section-expander";
import { normalizeFinalSeo, type FinalSeoNormalizerResult } from "@/lib/blog/final-seo-normalizer";
import { createArticleIntegrityBaseline, validateFinalArticleIntegrity, validateWordpressBlockPairs, type ArticleIntegrityBaseline } from "@/lib/blog/article-integrity";
import { extractFaqBlock, extractCtaFromConclusion, stripProtectedBlocksFromConclusion, countCtaHeadings, countSignupUrls, countFaqBlocks } from "@/lib/blog/protected-block-extractor";
import { validateFinalArticleInvariants } from "@/lib/blog/article-final-invariants";
import { FLESCH_MIN, FLESCH_MAX, KEYPHRASE_MAX } from "@/lib/services/generation-constants";
import { countExactPhrase, extractReadableText, getFirstNReadableWords, countCtaHeadingTags, hasLanguageSwitcher, countEditorialExternalLinks, extractH2Texts, extractParagraphTexts, countSentences } from "@/lib/seo/seo-text-utils";
import { type ArticleDocument, type ArticleSection, type ProtectedArticleBlock, renderArticleDocument, fingerprintHtml, classifyHeadings, renderFaqSchema, extractEditableContent, applyEditableContent, detectClaimConflicts, validateFaqParity, detectNestedParagraphs, extractVisibleFaqFromArticle, type ClaimConflict } from "@/lib/blog/article-document";
import { buildPolicy, analyzeFinalArticle, evaluatePolicy } from "@/lib/blog/final-article-policy";
import { recordStage, type PipelineState, validatePipelineOrder, createPipelineState, runPostAssemblyPipeline, guardStageOutput, type PipelineDependencies } from "@/lib/pipeline/blog-generation-pipeline";
import * as fs from "fs";
import * as path from "path";

// ── Failed JSON response saving ──

function saveFailedJsonResponse(stage: string, rawContent: string): string | null {
  try {
    const dir = path.resolve("debug");
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
    const safeStage = stage.replace(/[^a-zA-Z0-9_-]/g, "_");
    const filename = `failed-deepseek-response-${safeStage}-${timestamp}.txt`;
    const filepath = path.join(dir, filename);
    fs.writeFileSync(filepath, rawContent, "utf-8");
    console.log(`[DEEPSEEK-DIAG] Failed response saved: ${filepath}`);
    return filepath;
  } catch (e) {
    console.error(`[DEEPSEEK-DIAG] Could not save failed response: ${e instanceof Error ? e.message : String(e)}`);
    return null;
  }
}

/**
 * Parse a DeepSeek response with full diagnostics. On failure, saves raw content
 * to debug/ and reports parsing context.
 */
function parseDeepSeekJson(stage: string, content: string): unknown {
  // Log raw content diagnostics
  console.log(`[DEEPSEEK-DIAG:${stage}] type=${typeof content} length=${content.length}`);
  const first500 = content.substring(0, 500);
  const last500 = content.substring(Math.max(0, content.length - 500));
  console.log(`[DEEPSEEK-DIAG:${stage}] first500="${first500.replace(/\n/g, "\\n").replace(/\r/g, "\\r")}"`);
  console.log(`[DEEPSEEK-DIAG:${stage}] last500="${last500.replace(/\n/g, "\\n").replace(/\r/g, "\\r")}"`);

  try {
    return robustJsonParse(content, stage);
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err);
    console.error(`[DEEPSEEK-DIAG:${stage}] PARSE FAILED: ${errMsg}`);
    
    // Extract position info
    const posMatch = errMsg.match(/position\s+(\d+)/i);
    if (posMatch) {
      const pos = parseInt(posMatch[1]);
      const ctxBefore = content.substring(Math.max(0, pos - 200), pos).replace(/\n/g, "\\n");
      const ctxAfter = content.substring(pos, Math.min(content.length, pos + 200)).replace(/\n/g, "\\n");
      console.error(`[DEEPSEEK-DIAG:${stage}] errorPosition=${pos}`);
      console.error(`[DEEPSEEK-DIAG:${stage}] contextBefore=${ctxBefore}`);
      console.error(`[DEEPSEEK-DIAG:${stage}] contextAfter=${ctxAfter}`);
    }

    saveFailedJsonResponse(stage, content);
    throw err;
  }
}

// ── Diagnostic trace ──
function traceH2(stage: string, headings: string[], keyphrase: string) {
  const kp = keyphrase.toLowerCase();
  if (!kp) return;
  console.log(`\n[TRACE:H2] === ${stage} (${headings.length} headings) ===`);
  for (let i = 0; i < headings.length; i++) {
    const has = headings[i].toLowerCase().includes(kp);
    console.log(`[TRACE:H2]   [${i}] "${headings[i].substring(0, 80)}" — keyphrase: ${has ? "YES" : "NO"}`);
  }
  console.log(`[TRACE:H2] === end ${stage} ===\n`);
}

// ── Structural integrity ──
/** Strip all WordPress H2 heading blocks and bare <h2> tags from section body.
 *  Assembly is the SOLE owner of main outline H2 headings. */
function stripMainH2Blocks(html: string): string {
  let result = html;
  // WordPress block format: <!-- wp:heading {"level":2} --><h2>...</h2><!-- /wp:heading -->
  result = result.replace(/<!--\s*wp:heading\s*\{[^}]*"level"\s*:\s*2[^}]*\}\s*-->\s*<h2[^>]*>[\s\S]*?<\/h2>\s*<!--\s*\/wp:heading\s*-->/gi, "");
  // Bare <h2> tags
  result = result.replace(/<h2[^>]*>[\s\S]*?<\/h2>/gi, "");
  return result;
}

/** Validate WordPress block pairing using type-aware stack-based matching.
 *  Returns per-type mismatch details and a list of specific issues. */
function validateWpBlocks(html: string): { opening: number; closing: number; mismatches: number; issues: string[] } {
  const result = validateWordpressBlockPairs(html);
  const opening = (html.match(/<!--\s*wp:\w+/gi) || []).length;
  const closing = (html.match(/<!--\s*\/wp:\w+/gi) || []).length;
  return { opening, closing, mismatches: result.valid ? 0 : 1, issues: result.issues };
}

/**
 * Extract the CTA block from the conclusion ONLY (not from the full article).
 * Searching the full article caused overmatching: the regex matched from the
 * FAQ's <!-- wp:html --> opener through to the CTA's <!-- /wp:html --> closer,
 * capturing FAQ schema + conclusion paragraphs + CTA in a single oversized block.
 */
function traceHtmlH2(stage: string, html: string, keyphrase: string) {
  const kp = keyphrase.toLowerCase();
  if (!kp || !html) return;
  const h2Regex = /<h2[^>]*>([\s\S]*?)<\/h2>/gi;
  const matches: string[] = [];
  let m: RegExpExecArray | null;
  while ((m = h2Regex.exec(html)) !== null) {
    matches.push(m[1]);
  }
  console.log(`\n[TRACE:HTML] === ${stage} (${matches.length} H2s in HTML) ===`);
  for (let i = 0; i < matches.length; i++) {
    const has = matches[i].toLowerCase().includes(kp);
    console.log(`[TRACE:HTML]   [${i}] "${matches[i].substring(0, 80)}" — keyphrase: ${has ? "YES" : "NO"}`);
  }
  console.log(`[TRACE:HTML] === end ${stage} ===\n`);
}

// ── Post-assembly checkpoint helpers ──

function logPostMemory(label: string): void {
  const mem = process.memoryUsage();
  console.log(`[POST-MEM-${label}] heapUsed=${Math.round(mem.heapUsed / 1024)}KB heapTotal=${Math.round(mem.heapTotal / 1024)}KB rss=${Math.round(mem.rss / 1024)}KB external=${Math.round(mem.external / 1024)}KB`);
}

function logPostSize(label: string, html: string): void {
  console.log(`[POST-SIZE-${label}] chars=${html.length} words~=${html.split(/\s+/).filter(Boolean).length} type=${typeof html}`);
}

// ── Stage validation (defined in pipeline module, imported above) ──

interface GeneratedBlog {
  title: string;
  slug: string;
  metaDescription: string;
  excerpt: string;
  blog: string;
  faq: { question: string; answer: string }[];
  internalLinks: string[];
  externalLinks: string[];
  categories: string[];
  tags: string[];
  readingTime: string;
  summary: string;
}

export async function POST(request: Request) {
  const startTime = Date.now();

  try {
    const userId = await getCurrentUserId();
    const body = await request.json();
    const projectId = body.projectId;

    if (!projectId) {
      return NextResponse.json(
        { error: "projectId is required" },
        { status: 400 }
      );
    }

    const project = await projectRepository.findByIdAndUser(
      Number(projectId),
      userId
    );

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 });
    }

    const telemetry = new GenerationTelemetry();
    const trackedChat = async (stage: string, messages: Parameters<typeof chatWithRetry>[0], options?: Parameters<typeof chatWithRetry>[1]) => {
      const promptChars = messages.reduce((s, m) => s + m.content.length, 0);
      let result: Awaited<ReturnType<typeof chatWithRetry>>;
      try {
        result = await chatWithRetry(messages, options);
        telemetry.recordAiCall({ stage, durationMs: 0, promptChars, completionChars: result.content.length, completed: true, jsonRepaired: false });
      } catch (e) {
        telemetry.recordAiCall({ stage, durationMs: 0, promptChars, completionChars: 0, completed: false, jsonRepaired: false });
        throw e;
      }
      return result;
    };

    /**
     * Wraps trackedChat with a fixed stage name for use in GenContext.
     * Fixes the t.reduce is not a function bug caused by argument position mismatch
     * when trackedChat (stage, messages, options) is called as chatWithRetry (messages, options).
     */
    function makeTrackedChatForStage(stage: string): typeof chatWithRetry {
      return ((messages: Parameters<typeof chatWithRetry>[0], options?: Parameters<typeof chatWithRetry>[1]) =>
        trackedChat(stage, messages, options)) as typeof chatWithRetry;
    }

    telemetry.startTimer("total");

    // ===== LOG STEP 1: DATABASE VALUES =====
    console.log("[generate-blog:STEP1] Project from DB:");
    console.log(`  name: "${project.name}"`);
    console.log(`  keyword: "${project.keyword}"`);
    console.log(`  audience: "${project.audience}"`);
    console.log(`  country: "${project.country}"`);
    console.log(`  word_count (raw): ${(project as Record<string, unknown>).word_count} (type: ${typeof (project as Record<string, unknown>).word_count})`);
    console.log(`  status: "${project.status}"`);
    console.log(`  content length: ${(project.content ?? "").length} chars`);

    const research = await researchRepository.findByProject(Number(projectId));
    const knowledge = await knowledgeRepository.findByUser(userId);

    console.log(`[generate-blog:STEP1] Research items: ${research.length}`);
    console.log(`[generate-blog:STEP1] Knowledge items: ${knowledge.length}`);

    await promptSectionRepository.seedDefaults(userId);
    const promptSections = await promptSectionRepository.findByUser(userId);

    console.log(`[generate-blog:STEP1] Prompt sections: ${promptSections.length}`);
    const coreSections = ["brand_voice", "seo_rules", "formatting_rules", "hong_kong_context", "blog_structure", "cta", "publish_checklist"];
    for (const s of promptSections) {
      const key = (s as Record<string, unknown>).section_key as string;
      const content = (s.content ?? "") as string;
      const isCore = coreSections.includes(key);
      const prefix = isCore ? "✓" : " ";
      console.log(`  ${prefix} ${key}: ${content.length} chars — "${content.substring(0, 100).replace(/\n/g, ' ')}..."`);
    }

    const context = {
      project: {
        name: project.name,
        keyword: project.keyword,
        audience: project.audience,
        country: project.country,
        wordCount: Number((project as Record<string, unknown>).word_count ?? 0),
        content: project.content ?? "",
        status: project.status,
      },
      research: research.map((r) => ({
        category: r.category,
        title: r.title,
        snippet: r.snippet,
        url: r.url,
      })),
      knowledge: knowledge.map((k) => ({
        title: k.title,
        content: k.content,
        tags: k.tags,
      })),
      promptSections: promptSections.map((s) => ({
        key: (s as Record<string, unknown>).section_key as string ?? "",
        label: (s as Record<string, unknown>).section_key as string ?? "",
        content: s.content,
      })),
    };

    // ===== LOG STEP 2: PROMPT ASSEMBLY =====
    const { systemPrompt, userMessage } = buildBlogPrompt(context);

    // ── Compile prompt bundle once — all stages reuse this ──
    const { bundle, cacheHit, compileTimeMs } = getCompiledBundle(context);
    telemetry.recordMetric("promptCompileTimeMs", compileTimeMs);
    if (cacheHit) {
      telemetry.recordMetric("promptCacheHit", 1);
    } else {
      telemetry.recordMetric("promptCacheMiss", 1);
    }
    console.log(`[generate-blog:PROMPTS] Compile ${compileTimeMs}ms, cache ${cacheHit ? "HIT" : "MISS"}`);

    const hasWordCount = userMessage.includes("Target Word Count");
    const hasWordCountSystem = systemPrompt.includes("Target Word Count");
    console.log(`[generate-blog:STEP2] System prompt: ${systemPrompt.length} chars`);
    console.log(`[generate-blog:STEP2] User message: ${userMessage.length} chars`);
    console.log(`[generate-blog:STEP2] Total prompt: ${systemPrompt.length + userMessage.length} chars`);
    console.log(`[generate-blog:STEP2] Contains word count in user message: ${hasWordCount}`);
    console.log(`[generate-blog:STEP2] Contains word count in system prompt: ${hasWordCountSystem}`);
    console.log(`[generate-blog:STEP2] User message starts with: "${userMessage.substring(0, 200)}..."`);

    // ===== LOG STEP 3: DEEPSEEK REQUEST =====
    console.log(`[generate-blog:STEP3] DeepSeek call params: { responseFormat: "json_object", maxTokens: 16384 }`);
    console.log(`[generate-blog:STEP3] Full prompt (system+user): ${systemPrompt.length + userMessage.length} chars`);

    // ===== FULL PROMPT DUMP =====
    console.log("=== SYSTEM PROMPT (first 2000 chars) ===");
    console.log(systemPrompt.substring(0, 2000));
    console.log("=== USER MESSAGE (FULL) ===");
    console.log(userMessage);
    console.log("=== USER MESSAGE END ===");

    // Research check
    const researchInjected = context.research && context.research.length > 0;
    console.log(`=== Research injected into prompt: ${researchInjected ? "YES" : "NO"} ===`);
    if (researchInjected) {
      console.log(`=== Research count: ${context.research.length} items ===`);
      const top = context.research.slice(0, 3);
      top.forEach((r, i) => {
        console.log(`  [${i + 1}] title: "${r.title}"`);
        console.log(`           snippet: "${r.snippet.substring(0, 120)}..."`);
        console.log(`           url: "${r.url}"`);
      });
    }

    console.log(`=== TOTALS: system=${systemPrompt.length} user=${userMessage.length} combined=${systemPrompt.length + userMessage.length} ===`);
    // ============================

    const { chatWithRetry } = createDeepSeekClient();
    const targetWordCount = context.project.wordCount;

    // ── PHASE A: Generate outline (title + H2 headings) ──
    console.log("[generate-blog:OUTLINE] Generating outline...");
    telemetry.startTimer("outline");
    const outlineSystemPrompt = bundle.outlineSystem;
    const outlinePrompt = userMessage + "\n\n=== STEP 1 ===\nReturn ONLY an outline. Generate the title and 4-6 H2 section headings. Do NOT write full content yet. Return as JSON: {\"title\": \"...\", \"slug\": \"...\", \"metaDescription\": \"...\", \"h2Headings\": [\"Heading 1\", \"Heading 2\", ...]}.";
    const outlineRes = await trackedChat("outline",
      [{ role: "system", content: outlineSystemPrompt }, { role: "user", content: outlinePrompt }],
      { responseFormat: { type: "json_object" }, maxTokens: 8192 }
    );
    let outline: any;
    try {
      outline = robustJsonParse(outlineRes.content, "outline");
    } catch {
      console.error("[generate-blog:OUTLINE] JSON parse failed, retrying once...");
      const retryRes = await trackedChat("outline_retry",
        [{ role: "system", content: outlineSystemPrompt }, { role: "user", content: outlinePrompt + "\n\nCRITICAL: You MUST output valid JSON only. No markdown, no extra text." }],
        { responseFormat: { type: "json_object" }, maxTokens: 8192 }
      );
      try {
        outline = robustJsonParse(retryRes.content, "outline-retry");
      } catch {
        return NextResponse.json({ error: "Failed to parse outline JSON after retry" }, { status: 500 });
      }
    }
    const h2Headings: string[] = outline?.h2Headings ?? [];
    traceH2("1. Outline from DeepSeek", h2Headings, (context.project.keyword ?? "").toLowerCase());
    telemetry.endTimer("outline");
    telemetry.recordMetric("h2Headings", h2Headings.length);
    if (h2Headings.length === 0) {
      return NextResponse.json({ error: "Outline generation failed: no H2 headings returned" }, { status: 500 });
    }

    // Repair meta description in code
    const rawMeta = outline.metaDescription || "";
    const repairedMeta = repairMetaDescription(rawMeta, META_MIN, META_MAX);
    if (repairedMeta !== rawMeta) {
      console.log(`[generate-blog:OUTLINE] Meta repaired: ${rawMeta.length} → ${repairedMeta.length} chars`);
    }

    // Calculate dynamic word targets with generation buffer
    const requestedWordCount = context.project.wordCount || DEFAULT_WORD_COUNT;
    const internalTarget = Math.ceil(requestedWordCount * GENERATION_WORD_BUFFER);
    const { min: minWords, max: maxWords } = wordCountRange(requestedWordCount);
    const introTarget = Math.round(internalTarget * WORD_ALLOCATION.INTRO);
    const conclusionTarget = Math.round(internalTarget * WORD_ALLOCATION.CONCLUSION);
    const faqTarget = Math.round(internalTarget * WORD_ALLOCATION.FAQ);
    const h2TotalTarget = internalTarget - introTarget - conclusionTarget - faqTarget;
    const wordsPerSection = Math.round(h2TotalTarget / h2Headings.length);
    const exactKeyphraseTarget = keyphraseTarget(requestedWordCount);
    const kpRange = keyphraseRangeForWordCount(requestedWordCount);
    console.log(`[generate-blog:TARGETS] requested=${requestedWordCount} internal=${internalTarget} range=${minWords}-${maxWords} perSection=${wordsPerSection} kpRange=${kpRange.min}-${kpRange.max} kpTarget=${exactKeyphraseTarget}`);

    // Select the best H2 for keyphrase — must run BEFORE budget computation
    const keyphrase = (context.project.keyword ?? "").toLowerCase();
    let keyphraseH2Index = -1;
    if (keyphrase && h2Headings.length > 0) {
      const skipPatterns = /mistake|avoid|faq|conclusion|summary|final|wrap.?up/i;
      const kpWords = keyphrase.split(/\s+/);
      for (let i = 0; i < h2Headings.length; i++) {
        const h = h2Headings[i].toLowerCase();
        if (skipPatterns.test(h)) continue;
        if (kpWords.some((w) => h.includes(w))) { keyphraseH2Index = i; break; }
      }
      if (keyphraseH2Index === -1) {
        for (let i = 0; i < h2Headings.length; i++) {
          if (!skipPatterns.test(h2Headings[i].toLowerCase())) { keyphraseH2Index = i; break; }
        }
      }
      if (keyphraseH2Index === -1) keyphraseH2Index = 0;
      const original = h2Headings[keyphraseH2Index];
      h2Headings[keyphraseH2Index] = `${keyphrase}: ${original}`;
      console.log(`[generate-blog:H2-KEYPHRASE] Selected H2 #${keyphraseH2Index + 1}: "${original}" → "${h2Headings[keyphraseH2Index]}"`);
      traceH2("2. After keyphrase injection", h2Headings, keyphrase);
    }

    // ── Per-component keyphrase budgets ──
    // Classify headings: detect Common Mistakes and FAQ patterns to avoid double-counting
    const isMistakesHeading = (h: string) => /mistake|avoid|pitfall/i.test(h);
    const isFaqHeading = (h: string) => /faq|frequently|question/i.test(h);

    const classifiedComponents = h2Headings.map((h, idx) => {
      let type: ComponentKeyphraseBudget["componentType"] = "main-section";
      if (isMistakesHeading(h)) type = "mistakes";
      else if (isFaqHeading(h)) type = "faq";
      console.log(`[KP-BUDGET] section-${idx} heading="${h.substring(0, 60)}" type=${type} designatedH2=${idx === keyphraseH2Index}`);
      return {
        id: `section-${idx}`,
        type,
        plannedWordCount: wordsPerSection,
        containsDesignatedKeyphraseH2: idx === keyphraseH2Index,
      };
    });

    // Check if mistakes and FAQ types are already covered by headings
    const hasMistakesComponent = classifiedComponents.some((c) => c.type === "mistakes");
    const hasFaqComponent = classifiedComponents.some((c) => c.type === "faq");

    const allBudgetComponents = [
      { id: "intro", type: "introduction" as const, plannedWordCount: introTarget },
      ...classifiedComponents,
      // Only add synthetic components if not already covered by a heading
      ...(hasMistakesComponent ? [] : [{ id: "mistakes", type: "mistakes" as const, plannedWordCount: Math.round(wordsPerSection * 0.8) }]),
      ...(hasFaqComponent ? [] : [{ id: "faq", type: "faq" as const, plannedWordCount: faqTarget }]),
      { id: "conclusion", type: "conclusion" as const, plannedWordCount: conclusionTarget },
    ];

    const componentBudgets = allocateComponentKeyphraseBudgets({
      articleBudget: { min: kpRange.min, max: kpRange.max, preferred: exactKeyphraseTarget },
      components: allBudgetComponents,
    });
    const budgetMap = new Map(componentBudgets.map((b) => [b.componentId, b]));
    // Log budgets
    const budgetTotals = componentBudgets.reduce((acc, b) => ({ pref: acc.pref + b.preferred, max: acc.max + b.max }), { pref: 0, max: 0 });
    console.log(`[KP-BUDGET] article min=${kpRange.min} preferred=${exactKeyphraseTarget} max=${kpRange.max}`);
    for (const b of componentBudgets) {
      const comp = allBudgetComponents.find((c) => c.id === b.componentId);
      console.log(`[KP-BUDGET] id=${b.componentId} type=${b.componentType} heading="${comp?.id?.startsWith("section-") ? h2Headings[parseInt(b.componentId.replace("section-", ""))]?.substring(0, 50) ?? "" : ""}" plannedWords=${comp?.plannedWordCount ?? "N/A"} min=${b.min} preferred=${b.preferred} max=${b.max} designated=${!!b.containsDesignatedKeyphraseH2}`);
    }
    console.log(`[KP-BUDGET] totals preferred=${budgetTotals.pref} max=${budgetTotals.max}`);

    // ── Allocation invariants ──
    const preferredCapacity = budgetTotals.max;
    const expectedPreferred = Math.min(exactKeyphraseTarget, preferredCapacity);
    if (budgetTotals.pref !== expectedPreferred && preferredCapacity >= exactKeyphraseTarget) {
      console.warn(`[KP-BUDGET] WARNING: preferred total ${budgetTotals.pref} != expected ${expectedPreferred} (capacity=${preferredCapacity})`);
    }
    if (budgetTotals.pref < kpRange.min && preferredCapacity >= kpRange.min) {
      console.error(`[KP-BUDGET] ERROR: preferred total ${budgetTotals.pref} < article minimum ${kpRange.min} but capacity ${preferredCapacity} supports it`);
    }
    if (componentBudgets.length !== allBudgetComponents.length) {
      console.error(`[KP-BUDGET] ERROR: budget count ${componentBudgets.length} != component count ${allBudgetComponents.length}`);
    }

    // ── Authoritative section array (created once, never filtered/compacted/rebuilt) ──
    type SectionStatus = "pending" | "generated" | "recovered" | "missing" | "expanded" | "regenerated";
    interface GeneratedSection {
      index: number;
      heading: string;
      body: string;
      status: SectionStatus;
      error?: string;
    }
    const authoritativeSections: GeneratedSection[] = h2Headings.map((heading, index) => ({
      index,
      heading,
      body: "",
      status: "pending" as SectionStatus,
    }));
    function logSectionState(stage: string) {
      console.log(`[generate-blog:SECTION-STATE] stage=${stage} count=${authoritativeSections.length} indexes=[${authoritativeSections.map(s => s.index).join(",")}] statuses=[${authoritativeSections.map(s => s.status).join(",")}]`);
    }
    logSectionState("initialized");

    const generated: GeneratedBlog = {
      title: outline.title || "Untitled",
      slug: outline.slug || "",
      metaDescription: repairedMeta,
      blog: "",
      faq: [],
      internalLinks: [],
      externalLinks: [],
      categories: [],
      tags: [],
      readingTime: "",
      summary: "",
      excerpt: outline.excerpt || "",
    };

    // ── PHASE B–E (PARALLEL): Introduction, all H2 sections, Conclusion run concurrently ──
    console.log("[generate-blog:PARALLEL] Starting parallel generation (intro + sections + conclusion)...");
    telemetry.startTimer("parallel_block");

    // Build prompts for all parallel tasks
    const introSystemPrompt = bundle.introSystem;
    const introBudget = budgetMap.get("intro")!;
    const introUserMsg = `Write the introduction (${introTarget} words) for this blog. Use WordPress block format. Return as JSON: {"intro": "..."}.\n\nTitle: ${generated.title}\nMeta: ${generated.metaDescription}\nKeyword: ${context.project.keyword}\n\n${userMessage.substring(0, 1000)}${buildComponentBudgetPrompt(introBudget, context.project.keyword)}`;

    const sectionSystemPrompt = bundle.sectionSystem;

    const conclusionSystemPrompt = bundle.conclusionSystem;
    const conclusionBudget = budgetMap.get("conclusion")!;
    const conclusionUserMsg = `Write the conclusion (${conclusionTarget} words) for this blog. Include a CTA to create a B2I Hub profile. Return as JSON: {"conclusion": "..."}.\n\nTitle: ${generated.title}${buildComponentBudgetPrompt(conclusionBudget, context.project.keyword)}`;

    // ── Research source summary for section prompts ──
    const sectionResearchPrompt = context.research?.length
      ? `\n\nREFERENCE SOURCES (use these URLs when referencing claims — cite with descriptive anchor text like "According to [Source Name]..." and link to the URL):\n${context.research.map((r: any) => `- ${r.title || "Source"}: ${r.url || ""}${r.snippet ? ` (${r.snippet.substring(0, 120)})` : ""}`).join("\n")}`
      : "";

    // Build allowed research URL list for post-generation sanitization
    const researchUrls = (context.research || []).map((r: any) => r.url || r.link || "").filter(Boolean);

    // Create parallel tasks array
    type ParallelResult = { type: "intro" | "section" | "conclusion"; index?: number; heading?: string; content: string };
    const tasks: Promise<ParallelResult>[] = [];

    // Intro task
    tasks.push(
      trackedChat("intro",
        [{ role: "system", content: introSystemPrompt }, { role: "user", content: introUserMsg }],
        { responseFormat: { type: "json_object" }, maxTokens: 4096 }
      ).then((res) => ({ type: "intro" as const, content: (robustJsonParse(res.content, "intro") as Record<string, string>).intro || "" }))
    );

    // Section tasks (one per H2 heading)
    for (let i = 0; i < h2Headings.length; i++) {
      const h2Text = h2Headings[i];
      const prevHeading = i > 0 ? h2Headings[i - 1] : "(none)";
      const nextHeading = i < h2Headings.length - 1 ? h2Headings[i + 1] : "(none)";

      const sectionBudget = budgetMap.get(`section-${i}`)!;
      const sectionUserMsg = `Return section BODY content only. Do NOT return the section H2 heading. Do NOT output any level-2 heading. The application will insert the H2 heading separately. You may use H3 headings when needed. Start directly with a paragraph, list, table, quote, or H3 block.\n\nSection heading for context only (do NOT repeat):\n"${h2Text}"\n\nWrite the body content. Target exactly ${wordsPerSection} words. Use WordPress block format (<!-- wp:paragraph -->, <!-- wp:list -->).\n\nReturn as JSON: {\"body\": \"...\"}.\n\nArticle title: ${generated.title}\nPrevious heading: ${prevHeading}\nNext heading: ${nextHeading}\n\nGUIDANCE:\n- This section is one independent part of a larger article.\n- Do NOT repeat statistics, examples, or explanations likely covered in other sections (see headings above).\n- Assume the previous heading's topic has already been explained — do not reintroduce it.\n- Focus exclusively on the content for THIS heading.\n- End this section with a smooth transition toward the next heading (${nextHeading}).${sectionResearchPrompt}${buildComponentBudgetPrompt(sectionBudget, context.project.keyword)}`;

    tasks.push(
      trackedChat(`section_${i}`,
          [{ role: "system", content: sectionSystemPrompt }, { role: "user", content: sectionUserMsg }],
          { responseFormat: { type: "json_object" }, maxTokens: 8192 }
        ).then((res) => {
          const raw = (robustJsonParse(res.content, `section_${i}`) as Record<string, string>).body || "";
          let clean = stripMainH2Blocks(raw);
          if (clean !== raw) console.log(`[generate-blog:SANITIZE] Removed leaked H2 from section ${i}`);
          // Strip external links not from research sources
          if (researchUrls.length > 0) {
            const beforeUrls = clean;
            clean = sanitizeSectionUrls(clean, researchUrls);
            if (clean !== beforeUrls) {
              const removedUrls = (beforeUrls.match(/<a\b[^>]*href="([^"]*)"[^>]*>/gi) ?? []).filter(
                (a: string) => !clean.includes(a)
              );
              console.log(`[generate-blog:SANITIZE] section ${i}: removed ${removedUrls.length} non-research external link(s)`);
            }
          }
          return { type: "section" as const, index: i, heading: h2Text, content: clean };
        })
      );
    }

    // Conclusion task
    tasks.push(
      trackedChat("conclusion",
        [{ role: "system", content: conclusionSystemPrompt }, { role: "user", content: conclusionUserMsg }],
        { responseFormat: { type: "json_object" }, maxTokens: 4096 }
      ).then((res) => ({ type: "conclusion" as const, content: (robustJsonParse(res.content, "conclusion") as Record<string, string>).conclusion || "" }))
    );

    // Execute all parallel tasks with fault tolerance
    traceH2("3. Before parallel generation", h2Headings, keyphrase);
    const settled = await Promise.allSettled(tasks);

    // Classify results
    const successful: ParallelResult[] = [];
    const failed: { type: string; index?: number; heading?: string; error: string }[] = [];

    for (const s of settled) {
      if (s.status === "fulfilled") {
        successful.push(s.value);
      } else {
        // Determine which task failed from its position
        const idx = settled.indexOf(s);
        const taskIdx = idx as number;
        let taskType = "unknown";
        let taskIndex: number | undefined;
        let taskHeading: string | undefined;

        if (taskIdx === 0) {
          taskType = "intro";
        } else if (taskIdx === tasks.length - 1) {
          taskType = "conclusion";
        } else {
          const sectionIdx = taskIdx - 1;
          taskType = "section";
          taskIndex = sectionIdx;
          taskHeading = h2Headings[sectionIdx] ?? "unknown";
        }

        const reason = s.reason instanceof Error ? s.reason.message : String(s.reason);
        failed.push({ type: taskType, index: taskIndex, heading: taskHeading, error: reason });
        telemetry.recordTaskFailure(taskType, taskType === "section" ? `section_${taskIndex}` : taskType, reason);
        console.log(`[generate-blog:PARALLEL] FAILED: ${taskType}${taskIndex !== undefined ? ` #${taskIndex}` : ""} — ${reason}`);
      }
    }

    // ── Regenerate failed components before assembly ──
    const recovered: ParallelResult[] = [];

    if (failed.length > 0) {
      console.log(`[generate-blog:RECOVERY] Attempting to recover ${failed.length} failed task(s)...`);
      telemetry.startTimer("parallel_recovery");

      for (const f of failed) {
        try {
          if (f.type === "intro") {
            const newIntro = await regenerateIntroduction(
              { chatWithRetry: makeTrackedChatForStage("recovery_intro"), promptContext: context } as GenContext,
              generated.title, generated.metaDescription, keyphrase, introTarget,
            );
            recovered.push({ type: "intro", content: newIntro });
            telemetry.recordRecovery();
            console.log(`[generate-blog:RECOVERY] Intro recovered`);
          } else if (f.type === "conclusion") {
            const newConc = await regenerateConclusion(
              { chatWithRetry: makeTrackedChatForStage("recovery_conclusion"), promptContext: context } as GenContext,
              generated.title, conclusionTarget,
            );
            recovered.push({ type: "conclusion", content: newConc });
            telemetry.recordRecovery();
            console.log(`[generate-blog:RECOVERY] Conclusion recovered`);
          } else if (f.type === "section" && f.index !== undefined) {
            const prevHeading = f.index > 0 ? h2Headings[f.index - 1] : "none";
            const nextHeading = f.index < h2Headings.length - 1 ? h2Headings[f.index + 1] : "none";
            const newBody = await regenerateSection(
              { chatWithRetry: makeTrackedChatForStage("recovery_section"), promptContext: context } as GenContext,
              generated.title, f.heading || h2Headings[f.index], prevHeading, nextHeading, wordsPerSection, exactKeyphraseTarget, keyphrase,
            );
            recovered.push({ type: "section", index: f.index, heading: f.heading, content: newBody });
            telemetry.recordRecovery();
            console.log(`[generate-blog:RECOVERY] Section #${f.index} recovered`);
          }
        } catch (recoveryErr) {
          telemetry.recordUnrecovered();
          const msg = recoveryErr instanceof Error ? recoveryErr.message : String(recoveryErr);
          const stack = recoveryErr instanceof Error ? (recoveryErr.stack ?? "").split("\n").slice(0, 5).join("\n") : "no stack";
          console.error(`[generate-blog:RECOVERY] ${f.type}${f.index !== undefined ? ` #${f.index}` : ""} — FAILED: ${msg}`);
          console.error(`[generate-blog:RECOVERY-STACK]\n${stack}`);
          if (recoveryErr instanceof TypeError && msg.includes("reduce")) {
            console.error(`[generate-blog:RECOVERY-TYPE] typeof=${typeof (recoveryErr as any).value} inspected at recovery call for section ${f.index}`);
          }
        }
      }

      telemetry.endTimer("parallel_recovery");
    }

    // Combine successful + recovered
    const allResults = [...successful, ...recovered];

    // ── Write parallel results into authoritative section array (indexed write-back, never filter/rebuild) ──
    const hasIntro = allResults.some((r) => r.type === "intro");
    const sectionResults = allResults.filter((r): r is ParallelResult & { type: "section"; index: number } => r.type === "section");
    const totalSections = h2Headings.length;

    // Write section results back by index
    for (const sr of sectionResults) {
      if (sr.index >= 0 && sr.index < authoritativeSections.length) {
        authoritativeSections[sr.index].body = sr.content;
        authoritativeSections[sr.index].status = recovered.some((rr) => rr.type === "section" && rr.index === sr.index) ? "recovered" : "generated";
      }
    }
    // Mark all sections NOT in results as "missing" (preserves index, never removes)
    const resultIndices = new Set(sectionResults.map((s) => s.index));
    for (let i = 0; i < authoritativeSections.length; i++) {
      if (!resultIndices.has(i)) {
        authoritativeSections[i].body = "";
        authoritativeSections[i].status = "missing";
        authoritativeSections[i].error = "generation failed or unrecovered";
      }
    }
    logSectionState("after-parallel");

    // ── KP-COMPONENT: log each component's actual keyphrase count vs budget ──
    const kpLower = keyphrase.toLowerCase();
    for (let i = 0; i < authoritativeSections.length; i++) {
      const body = authoritativeSections[i].body || "";
      const actual = countExactPhrase(extractReadableText(body), keyphrase);
      const budget = budgetMap.get(`section-${i}`);
      if (budget) {
        console.log(`[KP-COMPONENT] id=section-${i} type=${budget.componentType} actual=${actual} preferred=${budget.preferred} max=${budget.max} valid=${actual <= budget.max}`);
      }
    }
    const introText = allResults.find((r) => r.type === "intro")?.content || "";
    const introActual = countExactPhrase(extractReadableText(introText), keyphrase);
    const introKpBudget = budgetMap.get("intro");
    if (introKpBudget) {
      console.log(`[KP-COMPONENT] id=intro type=introduction actual=${introActual} preferred=${introKpBudget.preferred} max=${introKpBudget.max} valid=${introActual <= introKpBudget.max}`);
    }
    const concText = allResults.find((r) => r.type === "conclusion")?.content || "";
    const concActual = countExactPhrase(extractReadableText(concText), keyphrase);
    const concKpBudget = budgetMap.get("conclusion");
    if (concKpBudget) {
      console.log(`[KP-COMPONENT] id=conclusion type=conclusion actual=${concActual} preferred=${concKpBudget.preferred} max=${concKpBudget.max} valid=${concActual <= concKpBudget.max}`);
    }

    const availableSections = sectionResults.length;

    if (!hasIntro) {
      console.error("[generate-blog:RECOVERY] Introduction missing after recovery — aborting");
      return NextResponse.json({ error: "Introduction generation failed and could not be recovered" }, { status: 500 });
    }

    const missingRatio = totalSections > 0 ? (totalSections - availableSections) / totalSections : 0;
    if (missingRatio > 0.3) {
      console.error(`[generate-blog:RECOVERY] ${totalSections - availableSections}/${totalSections} sections missing (${Math.round(missingRatio * 100)}%) — aborting`);
      return NextResponse.json({ error: `Too many section failures: ${totalSections - availableSections}/${totalSections} could not be generated` }, { status: 500 });
    }

    if (availableSections < totalSections) {
      console.warn(`[generate-blog:RECOVERY] ${totalSections - availableSections} section(s) unrecovered — continuing with partial content`);
    }

    const unrecoveredCount = totalSections - availableSections;
    if (unrecoveredCount > 0) {
      telemetry.recordMetric("unrecoveredSections", unrecoveredCount);
    }

    // ── Hard recovery: ensure NO missing sections reach assembly ──
    const missingSectionIndices: number[] = [];
    for (let i = 0; i < authoritativeSections.length; i++) {
      if (authoritativeSections[i].status === "missing" || !authoritativeSections[i].body) {
        missingSectionIndices.push(i);
      }
    }

    if (missingSectionIndices.length > 0) {
      console.warn(`[generate-blog:RECOVERY] ${missingSectionIndices.length} section(s) still missing — attempting hard recovery before assembly`);
      telemetry.startTimer("hard_recovery");

      for (const idx of missingSectionIndices) {
        const s = authoritativeSections[idx];
        const prevHeading = idx > 0 ? h2Headings[idx - 1] : "none";
        const nextHeading = idx < h2Headings.length - 1 ? h2Headings[idx + 1] : "none";
        try {
          const recoveredBody = await regenerateSection(
            { chatWithRetry: makeTrackedChatForStage("hard_recovery_section"), promptContext: context } as GenContext,
            generated.title, s.heading, prevHeading, nextHeading, wordsPerSection, exactKeyphraseTarget, keyphrase,
          );
          if (recoveredBody && countReadableWords(recoveredBody) > 0) {
            authoritativeSections[idx].body = recoveredBody;
            authoritativeSections[idx].status = "recovered";
            authoritativeSections[idx].error = undefined;
            console.log(`[generate-blog:RECOVERY] Hard recovery: section #${idx + 1} ("${s.heading.substring(0, 40)}") — recovered (${countReadableWords(recoveredBody)} words)`);
          } else {
            console.error(`[generate-blog:RECOVERY] Hard recovery: section #${idx + 1} returned empty body`);
          }
        } catch (hardErr) {
          console.error(`[generate-blog:RECOVERY] Hard recovery: section #${idx + 1} FAILED — ${hardErr instanceof Error ? hardErr.message : String(hardErr)}`);
        }
      }

      telemetry.endTimer("hard_recovery");

      // Recheck after hard recovery
      const stillMissing = authoritativeSections.filter((s) => s.status === "missing" || !s.body);
      if (stillMissing.length > 0) {
        const missingNames = stillMissing.map((s) => `#${s.index + 1} "${s.heading}"`).join(", ");
        console.error(`[generate-blog:RECOVERY] ${stillMissing.length} section(s) still unrecovered after hard recovery: ${missingNames} — aborting`);
        return NextResponse.json({
          error: `Section generation failed: ${stillMissing.length} section(s) could not be generated or recovered`,
          missingSections: stillMissing.map((s) => ({ index: s.index, heading: s.heading })),
        }, { status: 500 });
      }
    }

    // ── Component-level validation and safety caps before assembly ──
    const MAX_COMPONENT_CHARS = 500_000;   // 500KB per component
    const MAX_ARTICLE_CHARS = 2_000_000;    // 2MB total article
    const COMPONENT_GROWTH_WARN = 5;        // Warn if component grows 5x in one operation

    // Extract intro/conclusion
    let intro = allResults.find((r) => r.type === "intro")?.content || "";
    let conclusion = allResults.find((r) => r.type === "conclusion")?.content || "";

    // ── Component size safety caps ──
    const truncMessage = "\n<!-- content truncated: exceeded component size limit -->";
    if (intro.length > MAX_COMPONENT_CHARS) {
      console.error(`[generate-blog:SAFETY] Intro size ${intro.length} exceeds limit ${MAX_COMPONENT_CHARS} — truncating`);
      intro = intro.substring(0, MAX_COMPONENT_CHARS - truncMessage.length) + truncMessage;
    }
    for (let i = 0; i < authoritativeSections.length; i++) {
      const body = authoritativeSections[i].body || "";
      if (body.length > MAX_COMPONENT_CHARS) {
        console.error(`[generate-blog:SAFETY] Section ${i} body size ${body.length} exceeds limit ${MAX_COMPONENT_CHARS} — truncating`);
        authoritativeSections[i].body = body.substring(0, MAX_COMPONENT_CHARS - truncMessage.length) + truncMessage;
      }
    }
    if (conclusion.length > MAX_COMPONENT_CHARS) {
      console.error(`[generate-blog:SAFETY] Conclusion size ${conclusion.length} exceeds limit ${MAX_COMPONENT_CHARS} — truncating`);
      conclusion = conclusion.substring(0, MAX_COMPONENT_CHARS - truncMessage.length) + truncMessage;
    }

    if (!intro || countReadableWords(intro) === 0) {
      console.error("[generate-blog:RECOVERY] Introduction is empty after recovery — aborting");
      return NextResponse.json({ error: "Introduction generation failed and could not be recovered" }, { status: 500 });
    }

    console.log(`[generate-blog:INTRO] ${countReadableWords(intro)} words (${intro.length} chars)`);
    for (const s of authoritativeSections) {
      const bLen = (s.body || "").length;
      console.log(`[generate-blog:SECTION] ${s.index + 1}/${totalSections}: "${s.heading}" — ${countReadableWords(s.body)} words — ${bLen} chars — status=${s.status}`);
    }
    console.log(`[generate-blog:CONCLUSION] ${countReadableWords(conclusion)} words (${conclusion.length} chars)`);

    // Validate each component before assembly — uses type-aware WordPress block pairing
    let componentsValid = true;
    const componentIssues: string[] = [];
    const failedComponentIndices: number[] = [];
    for (let i = 0; i < authoritativeSections.length; i++) {
      const s = authoritativeSections[i];
      const wc = countReadableWords(s.body);
      const hasNestedP = /<p[^>]*>(?:(?!<\/p>).)*<p[^>]*>/g.test(s.body || "");
      const wpPairResult = validateWordpressBlockPairs(s.body || "");
      const hasWpIssue = !wpPairResult.valid;
      const valid = wc > 0 && !hasNestedP && !hasWpIssue;
      console.log(`[generate-blog:COMPONENT] section${i} valid=${valid} wc=${wc} nestedP=${hasNestedP} wpBlockValid=${!hasWpIssue}`);
      if (hasWpIssue) {
        for (const issue of wpPairResult.issues) {
          console.log(`[generate-blog:COMPONENT] section${i} wpIssue="${issue}"`);
        }
      }
      if (!valid) {
        componentsValid = false;
        failedComponentIndices.push(i);
        if (wc === 0) componentIssues.push(`section${i}: empty body`);
        if (hasNestedP) componentIssues.push(`section${i}: nested <p>`);
        if (hasWpIssue) componentIssues.push(`section${i}: wp block type mismatch (${wpPairResult.issues.slice(0, 2).join("; ")})`);
      }
    }

    if (!componentsValid) {
      console.error(`[generate-blog:COMPONENT] ${componentIssues.length} component issue(s): ${componentIssues.join("; ")}`);
      // Attempt regeneration for components with structural WP block issues
      console.log(`[generate-blog:COMPONENT] Attempting regeneration for ${failedComponentIndices.length} failed component(s)...`);
      // Iterate over a COPY — successful regenerations are removed from the original,
      // so we must not mutate the array being iterated.
      let remainingFailed: number[] = [];
      for (const idx of [...failedComponentIndices]) {
        const s = authoritativeSections[idx];
        const prevHeading = idx > 0 ? h2Headings[idx - 1] : "none";
        const nextHeading = idx < h2Headings.length - 1 ? h2Headings[idx + 1] : "none";
        const wpPairResult = validateWordpressBlockPairs(s.body || "");
        let repaired = false;
        try {
          const regeneratedBody = await regenerateSection(
            { chatWithRetry: makeTrackedChatForStage("component_fix"), promptContext: context } as GenContext,
            generated.title, s.heading, prevHeading, nextHeading, wordsPerSection, exactKeyphraseTarget, keyphrase,
          );
          if (regeneratedBody && countReadableWords(regeneratedBody) > 0) {
            const regenWpResult = validateWordpressBlockPairs(regeneratedBody);
            if (regenWpResult.valid) {
              authoritativeSections[idx].body = regeneratedBody;
              authoritativeSections[idx].status = "regenerated";
              console.log(`[generate-blog:COMPONENT] section${idx} successfully regenerated with valid WP blocks`);
              repaired = true;
              // Remove corresponding issue
              const issueIdx = componentIssues.findIndex((ci) => ci.startsWith(`section${idx}:`));
              if (issueIdx >= 0) componentIssues.splice(issueIdx, 1);
            } else {
              console.error(`[generate-blog:COMPONENT] section${idx} regeneration still has WP block issues: ${regenWpResult.issues.join("; ")}`);
            }
          }
        } catch (regenErr) {
          console.error(`[generate-blog:COMPONENT] section${idx} regeneration failed: ${regenErr instanceof Error ? regenErr.message : String(regenErr)}`);
        }
        if (!repaired) {
          remainingFailed.push(idx);
        }
      }
      // Replace original array with remaining failures (no splice during iteration)
      failedComponentIndices.length = 0;
      failedComponentIndices.push(...remainingFailed);

      // Recheck after regeneration
      if (failedComponentIndices.length > 0) {
        console.error(`[generate-blog:COMPONENT] ${failedComponentIndices.length} component(s) still structurally invalid after regeneration — aborting assembly`);
        return NextResponse.json({
          error: "Component structural validation failed",
          detail: componentIssues.join("; "),
          failedComponents: failedComponentIndices.map((i) => ({ index: i, heading: h2Headings[i] })),
        }, { status: 422 });
      }
      componentsValid = true;
    }

    // ── Build canonical ArticleDocument from generated components ──
    console.log("[ASSEMBLY] building ArticleDocument");
    const assemblyStartTime = Date.now();

    // Extract CTA from conclusion and strip it from conclusion HTML
    const initialCtaBlockHtml = extractCtaFromConclusion(conclusion);
    const initialCleanConclusion = stripProtectedBlocksFromConclusion(
      conclusion,
      initialCtaBlockHtml,
      "", // FAQ not generated yet
    );

    // Build language switcher
    const slugs = pairedSlugs(generated.slug || "blog-post");
    const langSwitcherHtml = `<!-- wp:html -->
<div class="b2i-language-switcher" data-language="en">
  <span>English</span> |
  <a href="/blog/${slugs.chineseSlug}">繁體中文</a>
</div>
<!-- /wp:html -->`;

    // Build ArticleDocument
    const articleDoc: ArticleDocument = {
      metadata: {
        title: generated.title,
        slug: generated.slug,
        metaDescription: generated.metaDescription,
        excerpt: generated.excerpt || "",
        targetWordCount: requestedWordCount,
        focusKeyphrase: keyphrase,
      },
      languageSwitcher: {
        id: "language-switcher",
        type: "language-switcher",
        html: langSwitcherHtml,
        fingerprint: fingerprintHtml(langSwitcherHtml),
      },
      introduction: { id: "intro", html: intro, wordCount: countReadableWords(intro), status: "generated" },
      sections: authoritativeSections.map((s) => ({
        id: `section-${s.index}`,
        html: s.body,
        wordCount: countReadableWords(s.body),
        status: s.status as ArticleSection["status"],
        heading: s.heading,
        headingLevel: 2 as const,
        sectionType: "main" as const,
      })),
      visibleFaq: generated.faq.map((f) => ({
        question: f.question,
        answerHtml: "", // filled after FAQ generation
        answerText: "", // filled after FAQ generation
      })),
      conclusion: { id: "conclusion", html: initialCleanConclusion, wordCount: countReadableWords(initialCleanConclusion), status: "generated" },
      cta: initialCtaBlockHtml ? {
        id: "cta",
        type: "cta",
        html: initialCtaBlockHtml,
        fingerprint: fingerprintHtml(initialCtaBlockHtml),
      } : null,
      faqSchema: null, // filled after FAQ generation
      insertedLinks: [],
    };

    // ── Construction-time invariant: CTA must not remain in conclusion ──
    if (articleDoc.cta && /app\.b2ihub\.com\/signup/i.test(articleDoc.conclusion.html)) {
      throw new Error("CTA signup URL remained inside canonical conclusion after extraction");
    }

    // Render canonical article
    let articleHtml = renderArticleDocument(articleDoc);
    let currentWordCount = countReadableWords(articleHtml);
    telemetry.endTimer("parallel_block");

    // ── Traces ──
    traceHtmlH2("4. After parallel block (from HTML)", articleHtml, keyphrase);
    traceH2("4. After parallel block (from array)", h2Headings, keyphrase);

    // ── PHASE D: Generate FAQ (sequential — depends on all section bodies) ──
    const sectionBodies = authoritativeSections.filter((s) => s.body).map((s) => s.body.substring(0, 500));
    const summaryText = sectionBodies.join("\n").substring(0, 1000);

    if (sectionBodies.length <= 1) {
      console.warn("[generate-blog:FAQ] Too few section bodies for FAQ — skipping");
      telemetry.recordWarning("faq_skipped:insufficient_sections");
    } else {
      console.log("[generate-blog:FAQ] Generating FAQ...");
      telemetry.startTimer("faq");
      const faqSystemPrompt = bundle.faqSystem;
      const faqPrompt = `Generate 4-6 FAQ questions and answers for this blog. Use <!-- wp:html --> blocks. Return as JSON: {\"faq\": [{\"question\": \"...\", \"answer\": \"...\"}], \"faqSchemaBlock\": \"...\"}.\n\nBlog title: ${generated.title}\nContent summary: ${summaryText}`;
      const faqRes = await trackedChat("faq",
        [{ role: "system", content: faqSystemPrompt }, { role: "user", content: faqPrompt }],
        { responseFormat: { type: "json_object" }, maxTokens: 8192 }
      );
      const faqData = robustJsonParse(faqRes.content, "faq") as Record<string, unknown>;
      generated.faq = (faqData.faq as Array<{ question: string; answer: string }>) || [];
      
      // Update ArticleDocument with FAQ entries (single source for visible + schema)
      articleDoc.visibleFaq = generated.faq.map((f) => ({
        question: f.question,
        answerHtml: f.answer || "",
        answerText: (f.answer || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim(),
      }));
      // Deterministic FAQ schema — never from the model
      const schemaHtml = renderFaqSchema(articleDoc.visibleFaq);
      articleDoc.faqSchema = {
        id: "faq-schema",
        type: "faq-schema",
        html: schemaHtml,
        fingerprint: fingerprintHtml(schemaHtml),
      };
      telemetry.endTimer("faq");
    }

    // Re-render after FAQ
    articleHtml = renderArticleDocument(articleDoc);
    traceHtmlH2("5. Before assembly (from HTML)", articleHtml, keyphrase);

    // ── KP-PRE-ASSEMBLY ──
    const preAssemblyWC = countReadableWords(articleHtml);
    const preAssemblyKP = countExactPhrase(extractReadableText(articleHtml), keyphrase);
    console.log(`[KP-PRE-ASSEMBLY] wordCount=${preAssemblyWC} exactCount=${preAssemblyKP} preferred=${exactKeyphraseTarget} min=${kpRange.min} max=${kpRange.max}`);

    telemetry.startTimer("assemble");
    generated.blog = articleHtml;
    telemetry.endTimer("assemble");

    // ── KP-RAW-ASSEMBLED ──
    const rawWC = countReadableWords(generated.blog);
    const rawKP = countExactPhrase(extractReadableText(generated.blog), keyphrase);
    console.log(`[KP-RAW-ASSEMBLED] wordCount=${rawWC} exactCount=${rawKP} preferred=${exactKeyphraseTarget} min=${kpRange.min} max=${kpRange.max}`);

    // ── Final diagnostics ──
    const assemblyTimeMs = Date.now() - assemblyStartTime;
    console.log(`[ASSEMBLY] finalChars=${generated.blog.length} finalWordCount=${countReadableWords(generated.blog)} assemblyTimeMs=${assemblyTimeMs}`);
    if (generated.blog.length > MAX_ARTICLE_CHARS) {
      console.error(`[ASSEMBLY] SAFETY — final article ${generated.blog.length} chars exceeds limit ${MAX_ARTICLE_CHARS} — truncating`);
      generated.blog = generated.blog.substring(0, MAX_ARTICLE_CHARS - truncMessage.length) + truncMessage;
    }

    // ── Assembly diagnostics ──
    const diagWpOpening = (generated.blog.match(/<!--\s*wp:\w+/gi) ?? []).length;
    const diagWpClosing = (generated.blog.match(/<!--\s*\/wp:\w+/gi) ?? []).length;
    console.log(`[generate-blog:ASSEMBLY-DIAG] wpOpening=${diagWpOpening} wpClosing=${diagWpClosing}`);

    // ── Create integrity baseline from initial assembly ──
    let assemblyBaseline = createArticleIntegrityBaseline(generated.blog);

    const assemblyGuard = guardStageOutput(generated.blog, null, assemblyBaseline, "assembly");
    if (!assemblyGuard.accepted) {
      generated.blog = assemblyGuard.html;
      console.warn("[generate-blog:INTEGRITY:assembly] Initial assembly failed structural validation — continuing with best available HTML");
    }

    // ── Build canonical pipeline state for stage tracking ──
    const pipelineState = createPipelineState({
      userId,
      projectId,
      keyphrase,
      requestedWordCount,
      articleDoc,
      h2Headings,
      authoritativeSections: authoritativeSections.map((s) => ({ index: s.index, heading: s.heading, body: s.body, status: s.status })),
      intro,
      conclusion,
      wordsPerSection,
      exactKeyphraseTarget,
      policy: buildPolicy(requestedWordCount, wordCountRange(requestedWordCount).min, wordCountRange(requestedWordCount).max),
      ctx: context,
      wordMin: wordCountRange(requestedWordCount).min,
      wordMax: wordCountRange(requestedWordCount).max,
      systemPrompt,
      userMessage: "",
    });
    pipelineState.blog = generated.blog;
    await runPostAssemblyPipeline(pipelineState, {
      chatWithRetry,
      makeTrackedChatForStage,
      telemetry,
      context,
    } satisfies PipelineDependencies);
    generated.blog = pipelineState.blog;
    generated.title = pipelineState.title;
    generated.metaDescription = pipelineState.metaDescription;

    const wordMin = pipelineState.wordMin;
    const wordMax = pipelineState.wordMax;
    const retryCount = pipelineState.retryCount;
    const componentRegens = pipelineState.componentRegenerations;

    // ── Pipeline complete — all post-assembly stages handled ──
    const finalBlogHtml = generated.blog;
    const finalTitle = generated.title;
    const finalMetaDescription = generated.metaDescription;
    const finalWordCount = countReadableWords(finalBlogHtml);
    const titleHasKeyphrase = containsExactPhrase(finalTitle, keyphrase);

    console.log(`[generate-blog:FINAL-SEO] title=${finalTitle.length}ch words=${finalWordCount} range=${wordMin}-${wordMax}`);

    // ── Save/audit parity: use immutable values ──
    const generationTimeMs = Date.now() - startTime;
    const articleBodyText = finalBlogHtml
      .replace(/<!--[\s\S]*?-->/g, "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();

    // ── Pipeline complete — validate order ──
    const orderIssues = validatePipelineOrder(pipelineState);
    if (orderIssues.length > 0) {
      console.warn(`[PIPELINE] Stage order issues: ${orderIssues.map((i) => i.message).join("; ")}`);
    }
    console.log(`[PIPELINE] ${pipelineState.stageOutputs.length} stages recorded, order valid=${orderIssues.length === 0}`);

    // Save blog version with final values
    console.log("[POST-N21 before save");
    const nextVersion = await blogVersionRepository.getNextVersionNumber(Number(projectId));
    console.log(`[generate-blog:VERSION] Next version: ${nextVersion}`);

    // ── Compensation-based save: version create + project update ──
    // These two writes are not a true database transaction — if project update
    // fails after version creation, the version is deleted as best-effort rollback.
    // Failure to roll back is logged as a CRITICAL persistence inconsistency.
    let savedVersionId: number | null = null;
    try {
      const created = await blogVersionRepository.create({
        projectId: Number(projectId),
        userId,
        versionNumber: nextVersion,
        title: finalTitle,
        slug: generated.slug,
        metaDescription: finalMetaDescription,
        excerpt: generated.excerpt,
        blog: finalBlogHtml,
        faq: generated.faq,
        internalLinks: generated.internalLinks,
        externalLinks: generated.externalLinks,
        categories: generated.categories,
        tags: generated.tags,
        readingTime: generated.readingTime,
        wordCount: finalWordCount,
        summary: generated.summary,
        model: "section-by-section",
        generationTimeMs: Date.now() - startTime,
        tokenUsage: { totalTokens: 0 },
        status: "draft",
      });
      savedVersionId = (created as any).id ?? null;

      await projectRepository.update(Number(projectId), {
        content: finalBlogHtml,
      });
    } catch (saveErr) {
      const errMsg = saveErr instanceof Error ? saveErr.message : String(saveErr);
      console.error(`[generate-blog:SAVE] Compensation save failed: projectId=${projectId} versionId=${savedVersionId ?? "none"} error=${errMsg}`);

      // Roll back version if project update failed after version creation
      if (savedVersionId !== null) {
        try {
          await blogVersionRepository.delete(savedVersionId);
          console.log(`[generate-blog:SAVE] Rolled back version id=${savedVersionId} for projectId=${projectId}`);
        } catch (rollbackErr) {
          // CRITICAL: version exists in database but will never be linked to a successful response.
          // The project was NOT updated, so the version is orphaned.
          console.error(
            `[generate-blog:SAVE] CRITICAL — rollback failed for projectId=${projectId} versionId=${savedVersionId}: ` +
            `${rollbackErr instanceof Error ? rollbackErr.message : String(rollbackErr)}. ` +
            `Original error: ${errMsg}`
          );
          telemetry.recordWarning(`criticalPersistInconsistency:projectId=${projectId}:versionId=${savedVersionId}`);
        }
      }
      return NextResponse.json({
        error: "Failed to save article",
        detail: errMsg,
      }, { status: 500 });
    }

    console.log(`[generate-blog:FINAL-PARITY] blog=true title=${titleHasKeyphrase} meta=${finalMetaDescription.length > 0} words=${finalWordCount === countReadableWords(finalBlogHtml)}`);

    // ── AI log (non-fatal — failure must not affect the response) ──
    try {
      await aiLogRepository.create({
        userId,
        model: "section-by-section",
        endpoint: "/api/generate-blog",
        status: "success",
        projectId: Number(projectId),
        promptSize: systemPrompt.length + userMessage.length,
        completionSize: finalBlogHtml.length,
        tokensIn: 0,
        tokensOut: 0,
        tokensTotal: 0,
        generationTimeMs: Date.now() - startTime,
      });
    } catch (aiLogErr) {
      console.error("[generate-blog:AI-LOG] AI log write failed (non-fatal):", aiLogErr instanceof Error ? aiLogErr.message : String(aiLogErr));
    }
    console.log("[POST-N21 after save");

    // ── Quality scoring (on final immutable values) ──
    console.log("[POST-N22 before quality scoring");
    const estimatedTokens = Math.round((systemPrompt.length + userMessage.length) / 4 * (2 + h2Headings.length + 3));
    const qualityReport = buildGenerationReport(
      finalBlogHtml, finalTitle, finalMetaDescription,
      keyphrase, requestedWordCount, (generated.faq || []).length,
      generationTimeMs, retryCount, 0, componentRegens, pipelineState.warnings, estimatedTokens,
      articleDoc.sections.length, // editorial H2 count (excludes CTA heading)
    );
    console.log(formatReport(qualityReport));

    telemetry.recordMetric("qualityScore", qualityReport.qualityScore.overall);
    telemetry.recordMetric("wordCount", finalWordCount);
    telemetry.recordMetric("targetWordCount", requestedWordCount);
    telemetry.recordMetric("titleLength", finalTitle.length);
    telemetry.recordMetric("metaLength", finalMetaDescription.length);
    telemetry.endTimer("total");
    console.log("[POST-N22 after quality scoring, before response");

    // ── Analytics (passive) ──
    try {
      const analyticsRecord = buildAnalyticsRecord(
        Number(projectId),
        finalTitle,
        telemetry.generateReport(),
        qualityReport.qualityScore,
        requestedWordCount,
        finalWordCount,
        pipelineState.warnings,
        0,
        0,
      );
      await generationAnalyticsRepository.insert(analyticsRecord as unknown as Record<string, unknown>);
      console.log("[generate-blog:ANALYTICS] Saved");
    } catch (analyticsErr) {
      console.error("[generate-blog:ANALYTICS] Failed (non-fatal):", analyticsErr instanceof Error ? analyticsErr.message : String(analyticsErr));
    }

    // ── KP-FINAL ──
    const finalWC = countReadableWords(finalBlogHtml);
    const finalKP = countExactPhrase(extractReadableText(finalBlogHtml), keyphrase);
    const finalRange = keyphraseRangeForWordCount(finalWC);
    const finalInRange = finalKP >= finalRange.min && finalKP <= finalRange.max;
    console.log(`[KP-FINAL] wordCount=${finalWC} exactCount=${finalKP} preferred=${exactKeyphraseTarget} min=${finalRange.min} max=${finalRange.max} passed=${finalInRange}`);
    if (pipelineState.normalizationResult) {
      const beforeKP = pipelineState.normalizationResult.before.exactKeyphraseCount;
      const afterKP = pipelineState.normalizationResult.after.exactKeyphraseCount;
      const removed = Math.max(0, beforeKP - afterKP);
      const added = Math.max(0, afterKP - beforeKP);
      console.log(`[KP-FINAL] beforeNorm=${beforeKP} afterNorm=${afterKP} removed=${removed} added=${added}`);
    }

    // ── Quality diagnostics ──
    const finalMetrics = analyzeFinalArticle(finalBlogHtml, keyphrase);
    const qcTitleHasKp = finalTitle.toLowerCase().includes(keyphrase);
    const qcFirst100 = finalMetrics.keyphraseInFirst100Words;
    const qcSwitcher = hasLanguageSwitcher(finalBlogHtml);
    const qcCtaHeads = countCtaHeadingTags(finalBlogHtml);
    const qcEditorialLinks = countEditorialExternalLinks(finalBlogHtml);
    const qcRange = keyphraseRangeForWordCount(finalWC);
    const qcWpOk = validateWpBlocks(finalBlogHtml).mismatches === 0;
    console.log(`[QUALITY-CHECK] titleHasKeyphrase=${qcTitleHasKp} first100HasKeyphrase=${qcFirst100} languageSwitcher=${qcSwitcher} ctaHeadingCount=${qcCtaHeads} editorialExternalLinks=${qcEditorialLinks} wordCount=${finalWC} acceptedMinimum=${qcRange.min} acceptedMaximum=${qcRange.max} wordCountWithinRange=${finalWC >= qcRange.min && finalWC <= qcRange.max} wpBlocksValid=${qcWpOk}`);

    console.log("[POST-N23 before final response JSON");
    logPostMemory("23-response");
    return NextResponse.json(
      {
        success: true,
        version: nextVersion,
        title: finalTitle,
        slug: generated.slug,
        metaDescription: finalMetaDescription,
        excerpt: generated.excerpt,
        blog: finalBlogHtml,
        faq: generated.faq,
        internalLinks: generated.internalLinks,
        externalLinks: generated.externalLinks,
        categories: generated.categories,
        tags: generated.tags,
        readingTime: generated.readingTime,
        wordCount: finalWordCount,
        summary: generated.summary,
        model: "section-by-section",
        generationTimeMs: Date.now() - startTime,
        tokenUsage: { totalTokens: 0 },
        qualityScore: qualityReport.qualityScore,
        finalValidation: {
          h2Count: (finalBlogHtml.match(/<!--\s*wp:heading\s*\{[^}]*"level"\s*:\s*2[^}]*\}\s*-->/gi) ?? []).length,
          h2Expected: h2Headings.length,
          hasDuplicates: /<h2[^>]*>([\s\S]*?)<\/h2>\s*([\s\S]*?)<h2[^>]*>\s*\1\s*<\/h2>/i.test(finalBlogHtml),
          hasNestedParagraphs: detectNestedParagraphs(finalBlogHtml) > 0,
          hasLanguageSwitcher: /b2i-language-switcher/i.test(finalBlogHtml),
          hasFaqSchema: /FAQPage|application\/ld\+json.*faq/i.test(finalBlogHtml),
          titleLength: finalTitle.length,
          titleHasKeyphrase,
          wordCount: finalWordCount,
          wordCountRange: `${wordMin}-${wordMax}`,
        },
        normalization: pipelineState.normalizationResult ? {
          passed: pipelineState.normalizationResult.passed,
          changes: pipelineState.normalizationResult.changes.length,
          before: pipelineState.normalizationResult.before,
          after: pipelineState.normalizationResult.after,
          warnings: pipelineState.normalizationResult.warnings,
        } : null,
        telemetry: telemetry.generateReport(),
      },
      { status: 201 }
    );
  } catch (error) {
    const err = error instanceof Error ? error : new Error(String(error));
    console.error("[generate-blog:POST]", {
      errorName: err.constructor.name,
      message: err.message,
      stack: err.stack?.split("\n").slice(0, 10).join("\n"),
    });

    if (error instanceof Error && error.message === "Not authenticated") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    return NextResponse.json(
      {
        error: "Failed to generate blog",
        detail: error instanceof Error ? error.message : String(error),
      },
      { status: 500 }
    );
  }
}
