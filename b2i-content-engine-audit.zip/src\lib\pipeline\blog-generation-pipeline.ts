// ── Canonical blog generation pipeline ──
// All post-assembly stages extracted from route.ts.
// route.ts handles auth, section generation, initial assembly, then delegates here.

import type { ArticleDocument } from "@/lib/blog/article-document";
import { renderArticleDocument, fingerprintHtml, validateFaqParity, extractVisibleFaqFromArticle, detectNestedParagraphs, renderFaqSchema, detectClaimConflicts } from "@/lib/blog/article-document";
import { type FinalSeoNormalizerResult } from "@/lib/blog/final-seo-normalizer";
import { normalizeFinalSeo } from "@/lib/blog/final-seo-normalizer";
import {
  createArticleIntegrityBaseline,
  validateFinalArticleIntegrity,
  validateWordpressBlockPairs,
  type ArticleIntegrityBaseline,
} from "@/lib/blog/article-integrity";
import type { FinalArticlePolicy, FinalArticleMetrics } from "@/lib/blog/final-article-policy";
import { buildPolicy, analyzeFinalArticle, evaluatePolicy } from "@/lib/blog/final-article-policy";
import { countReadableWords, containsExactPhrase } from "@/lib/services/text-utils";
import { extractReadableText, getFirstNReadableWords, extractH2Texts, extractParagraphTexts, countSentences, countEditorialExternalLinks, hasLanguageSwitcher, countCtaHeadingTags, countExactPhrase } from "@/lib/seo/seo-text-utils";
import { keyphraseRangeForWordCount, MAX_SENTENCES_PER_PARAGRAPH } from "@/lib/services/generation-constants";
import { validateFinalArticleInvariants } from "@/lib/blog/article-final-invariants";
import { extractFaqBlock } from "@/lib/blog/protected-block-extractor";
import { insertExternalResearchLinks, deduplicateEditorialExternalLinks, ensureLanguageSwitcher, pairedSlugs } from "@/lib/services/article-postprocessors";
import { expandToMinimum, trimToMaximum, normalizeParagraphs } from "@/lib/services/section-expander";
import { runComponentRegeneration, regenerateSection } from "@/lib/services/component-regenerator";

// ── Types ──

export interface PipelineStageOutput {
  stage: string;
  inputFingerprint: string;
  outputFingerprint: string;
  accepted: boolean;
  fallbackSource?: string;
  metadata?: Record<string, unknown>;
}

export interface PipelineState {
  readonly userId: string;
  readonly projectId: string;
  readonly keyphrase: string;
  readonly requestedWordCount: number;
  blog: string;
  title: string;
  slug: string;
  metaDescription: string;
  excerpt: string;
  faq: Array<{ question: string; answer: string }>;
  internalLinks: any[];
  externalLinks: any[];
  categories: string[];
  tags: string[];
  readingTime: string;
  summary: string;
  articleDoc: ArticleDocument;
  stageOutputs: PipelineStageOutput[];
  h2Headings: string[];
  authoritativeSections: Array<{ index: number; heading: string; body: string; status: string }>;
  intro: string;
  conclusion: string;
  wordsPerSection: number;
  exactKeyphraseTarget: number;
  retryCount: number;
  componentRegenerations: number;
  warnings: string[];
  startTime: number;
  normalizationResult: FinalSeoNormalizerResult | null;
  normalizationAccepted: boolean;
  qualityReport: any | null;
  policy: FinalArticlePolicy;
  ctx: any;
  baseline: ArticleIntegrityBaseline | null;
  wordMin: number;
  wordMax: number;
  estimatedTokens: number;
  systemPrompt: string;
  userMessage: string;
  // Internal counters carried through stages
  currentWordCount: number;
  expansionAttempts: number;
  trimAttempts: number;
}

// ── Pipeline dependencies (AI and external services) ──

export interface PipelineDependencies {
  chatWithRetry: any;
  makeTrackedChatForStage: (stage: string) => any;
  telemetry: any;
  context: any;
}

// ── Helpers ──

function fp(html: string): string { return fingerprintHtml(html); }

interface StageValidationResult {
  valid: boolean; nestedParagraphs: number; malformedHeadings: number;
  wpBlocksValid: boolean; unclosedTags: string[]; issues: string[];
}

function runStageValidation(html: string, baseline: ArticleIntegrityBaseline, stage: string): StageValidationResult {
  const result = validateFinalArticleIntegrity(html, baseline);
  const unclosed = result.errors.filter((e) => e.startsWith("Unclosed HTML tags"));
  const unclosedTags = unclosed.length > 0 ? [unclosed[0]] : [];
  const wpPairResult = validateWordpressBlockPairs(html);
  const wpBlocksValid = wpPairResult.valid;
  const issues: string[] = [...result.errors];
  for (const wpIssue of wpPairResult.issues) issues.push(wpIssue);
  return { valid: result.valid && wpBlocksValid, nestedParagraphs: result.metrics.nestedParagraphCount,
    malformedHeadings: result.metrics.malformedHeadingCount, wpBlocksValid, unclosedTags, issues };
}

export function guardStageOutput(
  currentHtml: string, previousHtml: string | null, baseline: ArticleIntegrityBaseline, stage: string,
): { html: string; accepted: boolean } {
  const validation = runStageValidation(currentHtml, baseline, stage);
  if (validation.valid) return { html: currentHtml, accepted: true };
  if (previousHtml !== null) {
    const prevValidation = runStageValidation(previousHtml, baseline, `${stage}-fallback`);
    if (prevValidation.valid) return { html: previousHtml, accepted: false };
    throw new Error(`Stage ${stage}: both candidate and fallback invalid`);
  }
  throw new Error(`Stage ${stage}: no fallback, candidate invalid`);
}

export function recordStage(state: PipelineState, stageName: string, inputFp: string, outputFp: string, accepted: boolean, fallbackSource?: string, metadata?: Record<string, unknown>): void {
  state.stageOutputs.push({ stage: stageName, inputFingerprint: inputFp, outputFingerprint: outputFp, accepted, fallbackSource, metadata });
}

export function createPipelineState(params: {
  userId: string; projectId: string; keyphrase: string; requestedWordCount: number;
  articleDoc: ArticleDocument; h2Headings: string[];
  authoritativeSections: Array<{ index: number; heading: string; body: string; status: string }>;
  intro: string; conclusion: string; wordsPerSection: number; exactKeyphraseTarget: number;
  policy: FinalArticlePolicy; ctx: any; wordMin: number; wordMax: number;
  systemPrompt: string; userMessage: string;
  retryCount?: number; componentRegenerations?: number;
}): PipelineState {
  const blog = renderArticleDocument(params.articleDoc);
  return {
    userId: params.userId, projectId: params.projectId, keyphrase: params.keyphrase,
    requestedWordCount: params.requestedWordCount, blog,
    title: params.articleDoc.metadata.title, slug: params.articleDoc.metadata.slug,
    metaDescription: params.articleDoc.metadata.metaDescription, excerpt: params.articleDoc.metadata.excerpt,
    faq: [], internalLinks: [], externalLinks: [], categories: [], tags: [], readingTime: "", summary: "",
    articleDoc: params.articleDoc, stageOutputs: [],
    h2Headings: params.h2Headings, authoritativeSections: params.authoritativeSections,
    intro: params.intro, conclusion: params.conclusion,
    wordsPerSection: params.wordsPerSection, exactKeyphraseTarget: params.exactKeyphraseTarget,
    retryCount: params.retryCount ?? 0, componentRegenerations: params.componentRegenerations ?? 0,
    warnings: [], startTime: Date.now(),
    normalizationResult: null, normalizationAccepted: false, qualityReport: null,
    policy: params.policy, ctx: params.ctx, baseline: null,
    wordMin: params.wordMin, wordMax: params.wordMax,
    estimatedTokens: 0, systemPrompt: params.systemPrompt, userMessage: params.userMessage,
    currentWordCount: 0, expansionAttempts: 0, trimAttempts: 0,
  };
}

export function validatePipelineOrder(state: PipelineState): Array<{ code: string; message: string; stage: string }> {
  const issues: Array<{ code: string; message: string; stage: string }> = [];
  const stages = state.stageOutputs.map((s) => s.stage);
  const required = ["expansion", "paragraphs", "regeneration", "external-links", "internal-links", "seo-normalization", "final-validation"];
  for (const req of required) {
    if (!stages.includes(req)) issues.push({ code: "MISSING_STAGE", message: `Required stage "${req}" not found`, stage: req });
  }
  // Check internal-links comes before seo-normalization
  const intIdx = stages.indexOf("internal-links");
  const seoIdx = stages.indexOf("seo-normalization");
  if (intIdx >= 0 && seoIdx >= 0 && intIdx > seoIdx) {
    issues.push({ code: "STAGE_ORDER", message: "internal-links must run before seo-normalization", stage: "internal-links" });
  }
  return issues;
}

// ── State snapshot for complete rollback ──

interface PipelineSnapshot {
  blog: string;
  articleDoc: string; // JSON serialized ArticleDocument
  authoritativeSections: string; // JSON serialized
  title: string;
  metaDescription: string;
  currentWordCount: number;
  expansionAttempts: number;
  trimAttempts: number;
  retryCount: number;
  componentRegenerations: number;
  normalizationResult: any;
  normalizationAccepted: boolean;
}

function snapshotState(state: PipelineState): PipelineSnapshot {
  return {
    blog: state.blog,
    articleDoc: JSON.stringify(state.articleDoc),
    authoritativeSections: JSON.stringify(state.authoritativeSections),
    title: state.title,
    metaDescription: state.metaDescription,
    currentWordCount: state.currentWordCount,
    expansionAttempts: state.expansionAttempts,
    trimAttempts: state.trimAttempts,
    retryCount: state.retryCount,
    componentRegenerations: state.componentRegenerations,
    normalizationResult: state.normalizationResult,
    normalizationAccepted: state.normalizationAccepted,
  };
}

function restoreSnapshot(state: PipelineState, snap: PipelineSnapshot): void {
  state.blog = snap.blog;
  state.articleDoc = JSON.parse(snap.articleDoc);
  state.authoritativeSections = JSON.parse(snap.authoritativeSections);
  state.title = snap.title;
  state.metaDescription = snap.metaDescription;
  state.currentWordCount = snap.currentWordCount;
  state.expansionAttempts = snap.expansionAttempts;
  state.trimAttempts = snap.trimAttempts;
  state.retryCount = snap.retryCount;
  state.componentRegenerations = snap.componentRegenerations;
  state.normalizationResult = snap.normalizationResult;
  state.normalizationAccepted = snap.normalizationAccepted;
}

// ── Individual stage runner ──
// Each stage captures its own fresh integrity baseline from its direct input HTML.
// If the candidate is rejected, the complete pre-stage state is restored.

function trackStage(state: PipelineState, stageName: string, preHtml: string, fn: (html: string) => string, preSnapshot?: PipelineSnapshot): PipelineState {
  const inputFp = fp(preHtml);
  const stageBaseline = createArticleIntegrityBaseline(preHtml);
  const snap = preSnapshot ?? snapshotState(state); // use caller-provided snapshot if available
  state.blog = fn(state.blog);
  const guard = guardStageOutput(state.blog, preHtml, stageBaseline, stageName);
  state.blog = guard.html;
  if (!guard.accepted) {
    restoreSnapshot(state, snap);
  }
  const outputFp = fp(state.blog);
  recordStage(state, stageName, inputFp, outputFp, guard.accepted, guard.accepted ? undefined : "pre-stage-restore");
  return state;
}

// ── Post-assembly pipeline ──

export async function runPostAssemblyPipeline(
  state: PipelineState,
  deps: PipelineDependencies,
): Promise<PipelineState> {
  state.baseline = createArticleIntegrityBaseline(state.blog);

  // Stage 1: Assembly gate
  state.stageOutputs.push({ stage: "assembly", inputFingerprint: fp(state.blog), outputFingerprint: fp(state.blog), accepted: true });

  // Stage 2: Claim check
  state = await runClaimCheck(state, deps);

  // Stage 3: Expansion
  state = await runExpansion(state, deps);

  // Stage 4: Trim
  state = await runTrim(state, deps);

  // Stage 5: Paragraph normalization
  state = trackStage(state, "paragraphs", state.blog, (html) => {
    const result = normalizeParagraphs(html, MAX_SENTENCES_PER_PARAGRAPH);
    return result.html;
  });

  // Stage 6: Component regeneration
  state = await runRegeneration(state, deps);

  // Stage 7: Language switcher
  state = trackStage(state, "language-switcher", state.blog, (html) => {
    const slugs = pairedSlugs(state.slug || "blog-post");
    const lsHtml = `<!-- wp:html --><div class="b2i-language-switcher" data-language="en"><span>English</span> | <a href="/blog/${slugs.chineseSlug}">繁體中文</a></div><!-- /wp:html -->`;
    return /b2i-language-switcher/i.test(html) ? html : lsHtml + "\n\n" + html;
  });

  // Stage 8: External links
  state = trackStage(state, "external-links", state.blog, (html) => {
    const researchItems = deps.context?.research || [];
    if (researchItems.length === 0) return html;
    const result = insertExternalResearchLinks(html, researchItems, 3);
    return result.html;
  });

  // Stage 9: External dedup
  state = trackStage(state, "external-dedup", state.blog, (html) => {
    const result = deduplicateEditorialExternalLinks(html);
    return result.html;
  });

  // Stage 10: Internal links (real injector)
  state = await runInternalLinks(state, deps);

  // Stage 11: SEO normalization
  state = await runSeoNormalization(state, deps);

  // Stage 12: Title repair
  state = trackStage(state, "title-repair", state.blog, (html) => {
    if (!containsExactPhrase(state.title, state.keyphrase)) {
      const titlePhrase = state.keyphrase.charAt(0).toUpperCase() + state.keyphrase.slice(1);
      const candidate = `${titlePhrase}: What You Need to Know`;
      if (candidate.length >= 40 && candidate.length <= 70) state.title = candidate;
    }
    return html;
  });

  // Stage 13: FAQ recovery
  state = trackStage(state, "faq-recovery", state.blog, (html) => {
    if (extractFaqBlock(html)) return html;
    const visibleFaq = extractVisibleFaqFromArticle(html);
    if (visibleFaq.length === 0) return html;
    const rebuilt = renderFaqSchema(visibleFaq.map((p: any) => ({ question: p.question, answerHtml: "", answerText: p.answerText })));
    const concIdx = html.lastIndexOf(state.articleDoc.conclusion.html.substring(0, 60));
    if (concIdx >= 0) return html.substring(0, concIdx) + rebuilt + "\n\n" + html.substring(concIdx);
    return html + "\n\n" + rebuilt;
  });

  // Stage 14: Final validation (rejects invalid HTML)
  state = trackStage(state, "final-validation", state.blog, (html) => {
    const result = runFinalValidation(state);
    if (!result.passed) {
      const reason = result.reasons.join("; ");
      console.error(`[PIPELINE:final-validation] REJECTED: ${reason}`);
      throw new Error(`Final validation failed: ${reason}`);
    }
    return html;
  });

  const orderIssues = validatePipelineOrder(state);
  if (orderIssues.length > 0) console.warn(`[PIPELINE] Order issues: ${orderIssues.map((i) => i.message).join("; ")}`);

  return state;
}

// ── Stage implementations ──

async function runClaimCheck(state: PipelineState, deps: PipelineDependencies): Promise<PipelineState> {
  const bodies = state.authoritativeSections.map((s) => ({ index: s.index, body: s.body }));
  const conflicts = detectClaimConflicts(bodies, { claims: [] });
  if (conflicts.length === 0) return state;

  const preHtml = state.blog;
  const snap = snapshotState(state);
  for (const c of conflicts) {
    const sectionB = state.authoritativeSections[c.sectionIndexB];
    if (!sectionB) continue;
    try {
      const prevHeading = c.sectionIndexB > 0 ? state.h2Headings[c.sectionIndexB - 1] : "none";
      const nextHeading = c.sectionIndexB < state.h2Headings.length - 1 ? state.h2Headings[c.sectionIndexB + 1] : "none";
      const regeneratedBody = await regenerateSection(
        { chatWithRetry: deps.makeTrackedChatForStage("claim_fix"), promptContext: deps.context } as any,
        state.title, sectionB.heading, prevHeading, nextHeading, state.wordsPerSection, state.exactKeyphraseTarget, state.keyphrase,
      );
      if (regeneratedBody && countReadableWords(regeneratedBody) > 0) {
        state.authoritativeSections[c.sectionIndexB].body = regeneratedBody;
        state.authoritativeSections[c.sectionIndexB].status = "regenerated";
        state.articleDoc.sections[c.sectionIndexB].html = regeneratedBody;
        state.articleDoc.sections[c.sectionIndexB].wordCount = countReadableWords(regeneratedBody);
        state.articleDoc.sections[c.sectionIndexB].status = "regenerated";
        state.blog = renderArticleDocument(state.articleDoc);
      }
    } catch (err) { /* continue */ }
  }
  return trackStage(state, "claim-check", preHtml, (html) => html, snap);
}

async function runExpansion(state: PipelineState, deps: PipelineDependencies): Promise<PipelineState> {
  state.currentWordCount = countReadableWords(state.blog);
  if (state.currentWordCount >= state.wordMin) return state;

  const preHtml = state.blog;
  const snap = snapshotState(state);
  const sectionsInput = state.authoritativeSections.map((s) => ({ index: s.index, heading: s.heading, body: s.body }));
  const result = await expandToMinimum({ chatWithRetry: deps.chatWithRetry }, sectionsInput.map((s) => ({ ...s })), sectionsInput, state.intro, state.conclusion, state.currentWordCount, state.wordMin, state.wordsPerSection);

  for (const s of result.sections) {
    if (s.index >= 0 && s.index < state.authoritativeSections.length) {
      state.authoritativeSections[s.index].body = s.body;
      state.authoritativeSections[s.index].status = "expanded";
    }
  }
  state.currentWordCount = result.finalWordCount;
  state.expansionAttempts = result.expansions;

  for (let i = 0; i < state.authoritativeSections.length && i < state.articleDoc.sections.length; i++) {
    state.articleDoc.sections[i].html = state.authoritativeSections[i].body;
    state.articleDoc.sections[i].wordCount = countReadableWords(state.authoritativeSections[i].body);
  }
  state.blog = renderArticleDocument(state.articleDoc);

  return trackStage(state, "expansion", preHtml, (html) => html, snap);
}

async function runTrim(state: PipelineState, deps: PipelineDependencies): Promise<PipelineState> {
  if (state.currentWordCount <= state.wordMax) return state;

  const preHtml = state.blog;
  const snap = snapshotState(state);
  const sectionsInput = state.authoritativeSections.map((s) => ({ index: s.index, heading: s.heading, body: s.body }));
  const result = await trimToMaximum({ chatWithRetry: deps.chatWithRetry }, sectionsInput.map((s) => ({ ...s })), state.intro, state.conclusion, state.currentWordCount, state.wordMax);

  for (const s of result.sections) {
    if (s.index >= 0 && s.index < state.authoritativeSections.length) state.authoritativeSections[s.index].body = s.body;
  }
  state.currentWordCount = result.finalWordCount;
  state.trimAttempts = result.trims;

  for (let i = 0; i < state.authoritativeSections.length && i < state.articleDoc.sections.length; i++) {
    state.articleDoc.sections[i].html = state.authoritativeSections[i].body;
    state.articleDoc.sections[i].wordCount = countReadableWords(state.authoritativeSections[i].body);
  }
  state.blog = renderArticleDocument(state.articleDoc);

  return trackStage(state, "trim", preHtml, (html) => html, snap);
}

async function runRegeneration(state: PipelineState, deps: PipelineDependencies): Promise<PipelineState> {
  const preHtml = state.blog;
  const snap = snapshotState(state); // captures title, metaDescription, etc.
  const genCtx: any = { chatWithRetry: deps.chatWithRetry, promptContext: deps.context };
  const { blog: regeneratedBlog, title: regeneratedTitle, meta: regeneratedMeta } = await runComponentRegeneration(
    genCtx, { title: state.title, metaDescription: state.metaDescription, blog: state.blog },
    state.h2Headings, state.keyphrase,
    { intro: state.wordsPerSection, conclusion: state.wordsPerSection, perSection: state.wordsPerSection, keyphraseTarget: state.exactKeyphraseTarget },
  );
  state.title = regeneratedTitle;
  state.metaDescription = regeneratedMeta;
  state.blog = regeneratedBlog;
  return trackStage(state, "regeneration", preHtml, (html) => html, snap);
}

async function runInternalLinks(state: PipelineState, deps: PipelineDependencies): Promise<PipelineState> {
  const preHtml = state.blog;
  try {
    const { seedDefaultLinks } = await import("@/lib/services/default-links");
    const { injectLinks } = await import("@/lib/services/link-injector");
    await seedDefaultLinks(state.userId);
    const result = await injectLinks(state.blog, state.userId);
    if (result.linksInjected > 0) {
      state.blog = result.modifiedContent;
    }
  } catch (err) {
    // Non-fatal — internal links are optional
  }
  return trackStage(state, "internal-links", preHtml, (html) => html);
}

async function runSeoNormalization(state: PipelineState, deps: PipelineDependencies): Promise<PipelineState> {
  const preHtml = state.blog;
  const snap = snapshotState(state); // captures normalizationResult, normalizationAccepted
  const FLESCH_MIN = 60, FLESCH_MAX = 80;
  try {
    const result = await normalizeFinalSeo(
      { html: state.blog, focusKeyphrase: state.keyphrase, targetWordCount: state.requestedWordCount, targetKeyphraseCount: state.exactKeyphraseTarget, minReadingEase: FLESCH_MIN, maxReadingEase: FLESCH_MAX },
      deps.chatWithRetry as any,
    );
    const safety = result.safety;
    const ctaOk = state.articleDoc.cta !== null;
    const accepted = result.passed === true && safety.protectedBlocksUnchanged && safety.linkDestinationsUnchanged && safety.wordpressBlocksValid && safety.faqSchemaPreserved && safety.languageSwitcherPreserved && ctaOk;
    state.normalizationResult = result;
    state.normalizationAccepted = accepted;
    if (accepted) state.blog = result.html;
    else state.blog = preHtml;
  } catch {
    state.blog = preHtml;
  }
  return trackStage(state, "seo-normalization", preHtml, (html) => html, snap);
}

export function runFinalValidation(state: PipelineState): { passed: boolean; reasons: string[] } {
  const reasons: string[] = [];
  const html = state.blog;
  const finalH2Count = (html.match(/<!--\s*wp:heading\s*\{[^}]*"level"\s*:\s*2[^}]*\}\s*-->/gi) ?? []).length;
  if (finalH2Count !== state.h2Headings.length) reasons.push(`h2=${finalH2Count}/${state.h2Headings.length}`);
  const faqBlock = extractFaqBlock(html);
  if (faqBlock) {
    const visibleFaq = extractVisibleFaqFromArticle(html);
    if (visibleFaq.length > 0) {
      const parity = validateFaqParity(visibleFaq.map((p) => ({ question: p.question, answerHtml: "", answerText: p.answerText })), faqBlock);
      if (!parity.valid) reasons.push(`faq: ${parity.issues.map((i) => i.detail).join("; ")}`);
    }
  }
  const invariant = validateFinalArticleInvariants(html);
  if (!invariant.valid) reasons.push(`invariants: ${invariant.errors.join("; ")}`);
  const metrics = analyzeFinalArticle(html, state.keyphrase);
  const policy = buildPolicy(state.requestedWordCount, state.wordMin, state.wordMax);
  const policyResult = evaluatePolicy(metrics, policy);
  if (!policyResult.passed) reasons.push(`policy: ${policyResult.reasons.join("; ")}`);
  return { passed: reasons.length === 0, reasons };
}
