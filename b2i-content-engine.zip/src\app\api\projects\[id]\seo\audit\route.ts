import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/services/auth";
import { requireProjectAccess } from "@/lib/services/project-authorization";
import { toErrorResponse, AppError } from "@/lib/services/errors";
import { seoRepository, blogVersionRepository } from "@/lib/repositories";
import { runAudit } from "@/lib/services/seo-auditor";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const userId = await getCurrentUserId();
    const { id } = await params;
    const project = await requireProjectAccess(userId, Number(id));

    const body = await request.json();
    const auditRunId = body._auditRunId || "unknown";
    console.log(`[SEO-AUDIT:${auditRunId}:api-input] keywordLen=${(body.keyword || "").length} blogLen=${(body.blog || "").length}`);
    const latestVersion = await blogVersionRepository.findLatest(Number(id));

    const title = (latestVersion as any)?.title || body.title || project.name || "";
    const metaDescription = (latestVersion as any)?.meta_description || body.metaDescription || "";
    const clientKeyword = typeof body.keyword === "string" ? body.keyword.trim() : "";
    const projectKeyword = typeof project.keyword === "string" ? project.keyword.trim() : "";
    const keyword = clientKeyword || projectKeyword;

    console.log(`[KEYPHRASE-RESOLVE] client="${clientKeyword}" project="${projectKeyword}" resolved="${keyword}" len=${keyword.length}`);

    if (!keyword) {
      console.warn("[seo:audit] No focus keyphrase available — marking keyphrase checks as not_applicable");
    }
    const blog = (latestVersion as any)?.blog || body.blog || (project as any).content || "";
    const faq = (latestVersion as any)?.faq || [];
    const targetWordCount = (project as any).wordCount || (project as any).word_count || 2500;
    const targetKeyphraseCount = 5;

    console.log(`[seo:audit] versionId=${(latestVersion as any)?.id} blogLen=${blog.length} title="${title.substring(0, 50)}..." metaLen=${metaDescription.length} keyword="${keyword}"`);

    if (!blog) {
      throw AppError.badRequest("No blog content to audit");
    }

    const result = runAudit({
      title,
      metaDescription,
      keyword,
      blog,
      faq,
      targetWordCount,
      targetKeyphraseCount,
    });

    await seoRepository.deleteByProject(Number(id));
    console.log(`[seo:audit] Deleted old checks for project ${id}`);

    const inserted = await seoRepository.createMany(
      result.checks.map((c) => ({
        projectId: Number(id),
        label: c.label,
        description: `${c.measuredValue} (target: ${c.targetValue}) — ${c.explanation}`,
        status: c.status,
        score: c.score,
        fix: c.status !== "not_applicable" ? c.explanation : "",
        category: c.category,
      }))
    );
    console.log(`[seo:audit] Inserted ${inserted.length} checks for project ${id}`);

    const kpCheck = result.checks.find((c) => c.id === "keyphrase_count");
    console.log(`[SEO-AUDIT:${auditRunId}:api-response] overallScore=${result.overallScore} kpStatus=${kpCheck?.status} kpScore=${kpCheck?.score} kpMeasured="${kpCheck?.measuredValue}"`);

    return NextResponse.json({ ...result, _auditRunId: auditRunId, _engineVersion: "keyphrase-fix-1" }, { status: 201 });
  } catch (error) {
    console.error("[seo:audit]", error);
    return toErrorResponse(error);
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const userId = await getCurrentUserId();
    const { id } = await params;
    await requireProjectAccess(userId, Number(id));

    await seoRepository.deleteByProject(Number(id));
    console.log(`[seo:audit] Deleted all checks for project ${id}`);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("[seo:audit:DELETE]", error);
    return toErrorResponse(error);
  }
}
