import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/services/auth";
import { toErrorResponse, AppError } from "@/lib/services/errors";
import { internalLinksRepository, suggestedLinksRepository } from "@/lib/repositories";

export async function GET() {
  try {
    const userId = await getCurrentUserId();
    const links = await internalLinksRepository.findByUser(userId);
    const suggestions = await suggestedLinksRepository.findPendingByUser(userId);
    return NextResponse.json({ links, pendingSuggestions: suggestions.length });
  } catch (error) {
    return toErrorResponse(error);
  }
}

export async function POST(request: Request) {
  try {
    const userId = await getCurrentUserId();
    const body = await request.json();

    if (!body.displayText || !body.url) {
      throw AppError.badRequest("displayText and url are required");
    }

    const link = await internalLinksRepository.create({
      createdBy: userId,
      displayText: body.displayText,
      urlSlug: body.urlSlug ?? body.url,
      keywords: body.keywords ?? [],
      priority: body.priority ?? 2,
      minPerArticle: body.minPerArticle ?? 1,
      maxPerArticle: body.maxPerArticle ?? 3,
      active: body.active ?? true,
    });

    return NextResponse.json(link, { status: 201 });
  } catch (error) {
    console.error("[internal-links:POST]", error);
    return toErrorResponse(error);
  }
}
