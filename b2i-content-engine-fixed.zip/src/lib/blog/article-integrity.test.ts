import { describe, it, expect } from "vitest";
import {
  tokenizeWordpressBlockComments,
  validateWordpressBlockPairs,
} from "@/lib/blog/article-integrity";

describe("wordpress block pair validation", () => {
  it("1. detects the exact malformed sequence: wp:html opener, incorrect wp:heading closer, later wp:html closer", () => {
    // Opener wp:html, then a wp:heading that is closed after the wp:html is closed
    // (crossed), plus an extra wp:html closer => imbalance + crossing.
    const html =
      "<!-- wp:html --><div class=\"cta\">" +
      "<!-- wp:heading {\"level\":2} --><h2>Heading</h2>" +
      "</div><!-- /wp:html -->" +
      "<!-- /wp:heading -->" +
      "<!-- /wp:html -->";
    const result = validateWordpressBlockPairs(html);
    expect(result.valid).toBe(false);
    // Diagnostic names must be wp:html / wp:heading, never wp:wp:html.
    for (const issue of result.issues) {
      expect(issue).not.toContain("wp:wp:");
    }
    // Crossed types: opened wp:html closed by wp:heading (or the reverse).
    expect(result.issues.some((i) => i.includes("type mismatch"))).toBe(true);
  });

  it("2. reports one extra closing heading marker", () => {
    const html =
      "<!-- wp:heading {\"level\":2} --><h2>A</h2><!-- /wp:heading -->" +
      "<!-- /wp:heading -->";
    const result = validateWordpressBlockPairs(html);
    expect(result.valid).toBe(false);
    expect(result.issues.some((i) => i.includes("Unexpected closing block wp:heading"))).toBe(true);
  });

  it("3. detects crossed WordPress block types", () => {
    const html =
      "<!-- wp:paragraph --><p>a</p>" +
      "<!-- wp:heading {\"level\":2} --><h2>b</h2>" +
      "<!-- /wp:paragraph -->" +
      "<!-- /wp:heading -->";
    const result = validateWordpressBlockPairs(html);
    expect(result.valid).toBe(false);
    expect(result.issues.some((i) => i.includes("type mismatch"))).toBe(true);
  });

  it("4. accepts valid whitespace variations in WordPress comments", () => {
    const html =
      "<!-- wp:paragraph --><p>a</p><!-- /wp:paragraph -->" +
      "<!--  wp:heading {\"level\":2}  --><h2>b</h2><!--  /wp:heading  -->" +
      "<!--\nwp:paragraph\n--><p>c</p><!--\n/wp:paragraph\n-->";
    expect(validateWordpressBlockPairs(html).valid).toBe(true);
  });

  it("5. diagnostic names show wp:html, never wp:wp:html", () => {
    const html = "<!-- wp:html --><div>a</div><!-- /wp:html --><!-- /wp:html -->";
    const result = validateWordpressBlockPairs(html);
    for (const issue of result.issues) {
      expect(issue).not.toContain("wp:wp:");
      expect(issue).toMatch(/wp:html/);
    }
  });

  it("8. render → parse → render preserves balanced WordPress structure", () => {
    // A balanced, well-formed document must pass.
    const html =
      "<!-- wp:html --><div class=\"b2i-language-switcher\"><span>EN</span></div><!-- /wp:html -->" +
      "<!-- wp:heading {\"level\":2} --><h2>Intro</h2><!-- /wp:heading -->" +
      "<!-- wp:paragraph --><p>Body text.</p><!-- /wp:paragraph -->" +
      "<!-- wp:heading {\"level\":2} --><h2>FAQ</h2><!-- /wp:heading -->" +
      "<!-- wp:html --><script type=\"application/ld+json\">{\"@type\":\"FAQPage\"}</script><!-- /wp:html -->" +
      "<!-- wp:html --><div class=\"cta\"><h2>Ready?</h2><a href=\"https://app.b2ihub.com/signup\">Go</a></div><!-- /wp:html -->";
    expect(validateWordpressBlockPairs(html).valid).toBe(true);
    // 3 wp:html blocks × 2 markers (open+close) = 6 tokens.
    expect(tokenizeWordpressBlockComments(html).filter((t) => t.type === "wp:html").length).toBe(6);
    // 2 wp:heading blocks × 2 markers = 4 tokens.
    expect(tokenizeWordpressBlockComments(html).filter((t) => t.type === "wp:heading").length).toBe(4);
  });

  it("does not accept crossed nested block markers", () => {
    const html =
      "<!-- wp:html --><div>" +
      "<!-- wp:heading {\"level\":2} --><h2>x</h2>" +
      "<!-- /wp:html -->" +
      "<!-- /wp:heading -->";
    expect(validateWordpressBlockPairs(html).valid).toBe(false);
  });
});
