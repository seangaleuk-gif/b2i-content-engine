import { describe, it, expect } from "vitest";
import { splitLongParagraphs } from "@/lib/services/text-utils";
import { validateWordpressBlockPairs } from "@/lib/blog/article-integrity";

describe("splitLongParagraphs wp:html boundary protection (regression)", () => {
  it("splits long paragraphs but preserves wp:html blocks byte-for-byte", () => {
    const longSentence = "Sentence one about local business. Sentence two explains a practical step. Sentence three gives the reason. Sentence four adds the result.";
    const html =
      "<!-- wp:paragraph --><p>" + longSentence + "</p><!-- /wp:paragraph -->" +
      "<!-- wp:html --><div class=\"cta\"><h2>Ready?</h2><a href=\"https://app.b2ihub.com/signup\">Go</a></div><!-- /wp:html -->";
    expect(validateWordpressBlockPairs(html).valid).toBe(true);
    const result = splitLongParagraphs(html, 3);
    expect(validateWordpressBlockPairs(result.html).valid).toBe(true);
    // The CTA wp:html block survives exactly once.
    expect(result.html.match(/<!--\s*wp:html\s*-->/g)?.length ?? 0).toBe(1);
    expect(result.html).toContain("https://app.b2ihub.com/signup");
    // The long paragraph was split.
    expect(result.splitCount).toBeGreaterThan(0);
  });

  it("never consumes a wp:html boundary on malformed unclosed <p> input", () => {
    const html =
      "<!-- wp:paragraph --><p>Sentence one about business. Sentence two explains the method. Sentence three gives reasons. Sentence four continues here." +
      "<!-- wp:html --><div class=\"cta\">" +
      "<!-- wp:heading {\"level\":2} --><h2>Heading</h2>" +
      "</div><!-- /wp:html -->" +
      "</p><!-- /wp:paragraph -->";
    const beforeHtmlCount = (html.match(/<!--\s*wp:html\s*-->/g) ?? []).length;
    const result = splitLongParagraphs(html, 3);
    const afterHtmlCount = (result.html.match(/<!--\s*wp:html\s*-->/g) ?? []).length;
    expect(afterHtmlCount).toBe(beforeHtmlCount);
    expect(result.html).toContain("<!-- wp:html --><div class=\"cta\">");
    expect(result.html).toContain("</div><!-- /wp:html -->");
    const htmlBlockCount = (result.html.match(/<!--\s*wp:html\s*-->[\s\S]*?<!--\s*\/wp:html\s*-->/g) ?? []).length;
    expect(htmlBlockCount).toBe(beforeHtmlCount);
  });
});
