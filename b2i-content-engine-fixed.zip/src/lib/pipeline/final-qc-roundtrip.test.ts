import { describe, it, expect } from "vitest";
import type { ArticleDocument, ArticleSection } from "@/lib/blog/article-document";
import {
  renderArticleDocument,
  renderFaqSchema,
  parseArticleDocumentFromHtml,
  countCanonicalVisibleWords,
  extractVisibleFaqFromArticle,
  validateFaqParity,
} from "@/lib/blog/article-document";
import { extractFaqBlock } from "@/lib/blog/protected-block-extractor";
import { validateWordpressBlockPairs } from "@/lib/blog/article-integrity";
import { analyzeFinalArticle, buildPolicy, evaluatePolicy } from "@/lib/blog/final-article-policy";
import { englishWordTolerance, dynamicFaqRange } from "@/lib/content-standards";

function paragraph(text: string): string {
  return `<!-- wp:paragraph --><p>${text}</p><!-- /wp:paragraph -->`;
}

const PROSE_SENTENCES = [
  "A simple marketing plan helps a small business stay consistent and clear.",
  "Local owners can list the questions customers actually ask every week.",
  "Turning those questions into short posts builds trust over time.",
  "A weekly routine keeps the work steady without adding extra stress.",
  "Reviews and replies show that a real person is listening to needs.",
  "Measuring profile visits and messages shows which ideas are working.",
  "Consistency matters more than a single perfect post or large budget.",
  "A clear voice helps a local business stand out in a busy market.",
  "Small steps, repeated regularly, create steady and honest growth.",
  "Focus on the people you serve and the results will follow naturally.",
];

function proseBlock(count: number): string {
  const sentences = [];
  for (let i = 0; i < count; i++) {
    sentences.push(PROSE_SENTENCES[(i + count) % PROSE_SENTENCES.length]);
  }
  return paragraph(sentences.join(" "));
}

function buildCompleteArticle(): ArticleDocument {
  const keyphrase = "hong kong sme marketing";

  const sections: ArticleSection[] = [
    { id: "s0", heading: "Why Hong Kong SMEs Need a Plan", headingLevel: 2, sectionType: "main", blocks: [], status: "generated" },
    { id: "s1", heading: "Steps to a Simple Marketing Routine", headingLevel: 2, sectionType: "main", blocks: [], status: "generated" },
    { id: "s2", heading: "Measuring What Matters", headingLevel: 2, sectionType: "main", blocks: [], status: "generated" },
    { id: "s3", heading: "Common Mistakes to Avoid", headingLevel: 2, sectionType: "main", blocks: [], status: "generated" },
    { id: "faq-section", heading: "Frequently Asked Questions", headingLevel: 2, sectionType: "faq-heading", blocks: [], status: "generated" },
  ];

  const faqCount = dynamicFaqRange(2000).min;
  const faqs = Array.from({ length: Math.max(4, faqCount) }, () => ({
    question: `What is a practical ${keyphrase} first step for local businesses?`,
    answerHtml: "",
    answerText: `Start with a small, useful routine and review real customer questions each week.`,
  }));

  const doc: ArticleDocument = {
    metadata: {
      title: `Hong Kong SME Marketing: A Practical Local Guide`,
      slug: "hong-kong-sme-marketing-practical-local-guide",
      metaDescription: "A practical guide to marketing for Hong Kong SMEs.",
      excerpt: "A practical local guide.",
      targetWordCount: 2000,
      focusKeyphrase: keyphrase,
    },
    languageSwitcher: {
      id: "sw",
      type: "language-switcher",
      html: `<!-- wp:html --><div class="b2i-language-switcher"><span>EN</span> | <a href="/blog/hong-kong-sme-marketing-practical-local-guide-zh">中文</a></div><!-- /wp:html -->`,
      fingerprint: "sw",
    },
    introduction: { id: "intro", blocks: [], status: "generated" },
    sections,
    conclusion: { id: "conclusion", blocks: [], status: "generated" },
    visibleFaq: faqs,
    cta: {
      id: "cta",
      type: "cta",
      html: `<!-- wp:html --><div class="cta-block"><h2>Ready to grow your brand?</h2><p>B2I Hub connects businesses directly with verified creators — no agencies, no commissions, no middlemen.</p><a href="https://app.b2ihub.com/signup">Create your free profile</a></div><!-- /wp:html -->`,
      fingerprint: "cta",
    },
    faqSchema: {
      id: "faq-schema",
      type: "faq-schema",
      html: renderFaqSchema(faqs),
      fingerprint: "schema",
    },
    insertedLinks: [],
  };

  // Populate sections/intro/conclusion with blocks (each ~3-5 sentences).
  doc.introduction.blocks = parseIntroBlocks(Array.from({ length: 4 }, () => proseBlock(5)).join("\n\n"));
  doc.sections.forEach((section, index) => {
    if (section.sectionType === "faq-heading") return;
    section.blocks = parseIntroBlocks(Array.from({ length: 6 + (index % 2) }, () => proseBlock(6)).join("\n\n"));
  });
  doc.conclusion.blocks = parseIntroBlocks(Array.from({ length: 3 }, () => proseBlock(5)).join("\n\n"));
  return doc;
}

function parseIntroBlocks(html: string): ArticleDocument["introduction"]["blocks"] {
  const blocks: ArticleDocument["introduction"]["blocks"] = [];
  const re = /<!--\s*wp:paragraph\s*-->\s*<p>([\s\S]*?)<\/p>\s*<!--\s*\/wp:paragraph\s*-->/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html)) !== null) {
    blocks.push({ id: `b-${blocks.length}`, type: "paragraph", content: [{ type: "text", text: m[1] }] });
  }
  return blocks;
}

describe("representative complete article regression (final-QC)", () => {
  it("9+10+11. full document round-trips: switcher, sections, conclusion, 4-6 FAQs, schema, single CTA", () => {
    const doc = buildCompleteArticle();
    const html = renderArticleDocument(doc);
    expect(validateWordpressBlockPairs(html).valid).toBe(true);

    // Exactly one CTA block, one CTA heading, one signup URL.
    expect((html.match(/class="cta-block"/g) ?? []).length).toBe(1);
    expect((html.match(/app\.b2ihub\.com\/signup/g) ?? []).length).toBe(1);
    expect((html.match(/<h2>Ready to grow your brand\?<\/h2>/g) ?? []).length).toBe(1);

    // render → parse → render preserves balanced WP structure.
    const parsed = parseArticleDocumentFromHtml(html, doc);
    expect(parsed.doc).toBeTruthy();
    const reRendered = renderArticleDocument(parsed.doc!);
    expect(validateWordpressBlockPairs(reRendered).valid).toBe(true);

    // FAQ and schema one-to-one and ordered.
    expect(doc.visibleFaq.length).toBeGreaterThanOrEqual(4);
    expect(doc.visibleFaq.length).toBeLessThanOrEqual(6);
    const canonical = extractVisibleFaqFromArticle(html, doc);
    const schemaHtml = extractFaqBlock(html);
    const parity = validateFaqParity(
      canonical.map((e) => ({ question: e.question, answerHtml: "", answerText: e.answerText })),
      schemaHtml,
    );
    expect(parity.valid).toBe(true);
    expect(canonical.length).toBe(doc.visibleFaq.length);
  });

  it("18. a representative complete article passes every hard final gate", () => {
    const doc = buildCompleteArticle();
    const keyphrase = doc.metadata.focusKeyphrase;
    const html = renderArticleDocument(doc);
    const range = englishWordTolerance(2000);
    const metrics = analyzeFinalArticle(
      html,
      keyphrase,
      doc.metadata.title,
      doc.metadata.metaDescription,
      2000,
      countCanonicalVisibleWords(doc),
    );
    const policy = buildPolicy(2000, range.min, range.max, keyphrase);
    const result = evaluatePolicy(metrics, policy);
    // Word count in range.
    expect(countCanonicalVisibleWords(doc)).toBeGreaterThanOrEqual(range.min);
    expect(countCanonicalVisibleWords(doc)).toBeLessThanOrEqual(range.max);
    // The hard gates are evaluated by evaluatePolicy; this fixture must pass.
    // Soft findings are allowed; hard failures must be empty.
    const hardFailures = result.reasons.filter((r) => r.includes("FAIL"));
    expect(hardFailures).toEqual([]);
  });
});
