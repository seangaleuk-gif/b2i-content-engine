# B2I Content Engine — Project Status

## Overall Goal

A full-stack content generation platform for Hong Kong SMEs. Generates SEO-optimised blog articles with Hong Kong–specific market context, local creator partnerships, and bilingual (English/Traditional Chinese) support. The engine manages the full lifecycle: outline generation, editorial section generation, FAQ/CTA injection, SEO normalisation, factual-scan validation, final validation, and publishing.

## Current Architecture

```
AI (DeepSeek)
  → structured JSON {"blocks":[...]}
  → normalizeAiEditorialPayload() → EditorialBlock[]
  → ArticleDocument (stores blocks as canonical editorial state)
  → renderEditorialBlocksToWordPress() → WordPress HTML
  → legacy HTML stage bridge (render → process → parse → validate → commit)
  → final publishing
```

### Canonical State Model

- **`ArticleDocument`** is the single canonical mutable article representation.
  - `introduction.blocks`, `sections[].blocks`, `conclusion.blocks` are `EditorialBlock[]`.
  - No dual `html` + `blocks` representation exists on editorial components.
- **`state.blog`** is a rendered HTML cache, regenerated from `ArticleDocument` after every committed change. Never treated as canonical.
- **`state.faq`** is synchronised from `articleDoc.visibleFaq`.

### Protected Non-Editorial HTML (intentionally remain strings)

These components are application-owned, never AI-generated, and stay as strings:

| Field | Purpose | Managed by |
|---|---|---|
| `languageSwitcher.html` | Bilingual slug toggle | `pairedSlugs`, always deterministic |
| `cta.html` | Signup call-to-action block | Pipeline `cta-preserve` stage, canonical HTML constant |
| `faqSchema.html` | `FAQPage` JSON-LD schema | `renderFaqSchema()` from `doc.visibleFaq` |
| `visibleFaq` (FAQ entries) | Q&A pairs | `extractFaqPairsFromSectionBody`, pipeline FAQ recovery |
| Rendered publication HTML | Final blog output | `renderArticleDocument()` at publishing boundary |

**Editorial component HTML is NOT directly persisted to the database.** The database stores:
- `blog` — the full rendered HTML (output of `renderArticleDocument`)
- `faq` — structured FAQ question/answer pairs
- Article metadata (title, slug, meta description, excerpt)

`ArticleDocument` is an in-memory model assembled during generation and not serialized to a persistent store.

## Completed Migration Stages

| Stage | Status | Details |
|---|---|---|
| EditorialBlock types | ✅ Complete | `InlineContent`, `EditorialBlock`, `AiEditorialBlock` in `article-content.ts` |
| AI payload normalisation | ✅ Complete | `normalizeAiEditorialPayload` with CTA-scoped rejection |
| WordPress renderer | ✅ Complete | `renderEditorialBlocksToWordPress` — only source of WP markup |
| Add parse5 DOM parser | ✅ Complete | `parseWordPressEditorialBlocks` for legacy HTML reconstruction |
| Conclusion markers | ✅ Complete | `<!-- b2i-conclusion-start -->` / `<!-- b2i-conclusion-end -->` |
| FAQ heading marker | ✅ Complete | `<!-- b2i-faq-heading -->` |
| Service-level retry tests | ✅ Complete | Dependency-injected `requestDeepSeek`, 13 strict tests |
| FAQ population in assembly | ✅ Complete | `articleDoc.visibleFaq` from FAQ section body |
| Conclusion prompt de-CTA'd | ✅ Complete | Removed CTA module from conclusion stage prompts |
| ArticleComponent → blocks | ✅ Complete (type) | `html` field removed from `ArticleComponent` interface |
| renderArticleDocument → blocks | ✅ Complete | Uses `renderEditorialBlocksToWordPress` |
| parseArticleDocumentFromHtml → blocks | ✅ Complete | Uses `parseWordPressEditorialBlocks` |
| Pipeline legacy bridge | ✅ Complete | Render → process → parse → validate → commit |
| CreatePipelineState faq sync | ✅ Complete | `state.faq` from `articleDoc.visibleFaq` |
| Default prompts updated | ✅ Complete | Structured JSON format, de-CTA'd conclusion |

## In-Progress Migration

| Item | Status | Details |
|---|---|---|
| `.html` → `renderComponentHtml()` in translation-service | ✅ Complete | All editorial `.html` reads/writes eliminated; `visibleFaq` is sole canonical FAQ representation |
| `.html` → `renderComponentHtml()` in SEO normaliser | 🔄 Not started | `firstBlock.html` accesses in `final-seo-normalizer.ts` operate on local `{ html: string }` helper type (not `ArticleComponent`); no compilation errors; migration deferred |
| `.html` → blocks in FAQ section body write | ✅ Removed | Dead assignments removed — FAQ section body was never consumed by `renderArticleDocument()`; `visibleFaq` is sole canonical FAQ representation |
| Translation assembler | ✅ Complete | Already uses `renderComponentHtml` |
| Test fixture update | ✅ Complete | All 3 test files migrated to `EditorialBlock[]`; all 30 migration-related failures resolved |
| FAQ parity validator strengthened | ✅ Complete | Empty questions and answers now correctly rejected |
| Structured-content migration checkpoint | ✅ Complete | Production clean, 944 tests passing, build green |
| Service block round-trip elimination | 🔄 Future work | Store normalized blocks directly, skip HTML → parse5 round trip |
| SEO normalizer block mutation | 🔄 Future work | Migrate `final-seo-normalizer.ts` from HTML string editing to `EditorialBlock[]` mutation |
| Translation structured-text-node | 🔄 Future work | Translate `InlineContent[].text` directly instead of HTML bridge |

## Repository-Wide `.html` Dependency Audit

The audit was performed by searching every non-test `.ts` file for `.html` access on `ArticleComponent`/`ArticleSection` objects. Results are grouped by migration category, not by file.

### Translation (temporary HTML compatibility path)

| File | Lines | Access Type |
|---|---|---|
| ~~`translation-service.ts`~~ | ~~263, 264, 296~~ | ~~**Read** — `enDoc.introduction.html` → `protectNumbersInHtml` — **Fixed** → `renderComponentHtml()`~~ |
| ~~`translation-service.ts`~~ | ~~311, 312~~ | ~~**Read** — `section.html` → `protectNumbersInHtml` — **Fixed** → `renderComponentHtml()`~~ |
| ~~`translation-service.ts`~~ | ~~368~~ | ~~**Read** — status ternary — **Fixed** → `section.blocks.length > 0`~~ |
| ~~`translation-service.ts`~~ | ~~386, 387, 412~~ | ~~**Read** — `enDoc.conclusion.html` — **Fixed** → `renderComponentHtml()`~~ |
| `translation-service.ts` | 430 | ~~**Write** — `faqSection.html = faqBody` (FAQ HTML construction) — **Removed** — dead state; `visibleFaq` is sole canonical FAQ representation~~ |

**Risk:** Low. Total editorial `.html` references eliminated from production code. Translation reads via `renderComponentHtml()` are the last HTML compatibility path — deferred to future migration phase.

### Translation Assembly

| File | Lines | Access Type |
|---|---|---|
| `translation-assembler.ts` | 22–23 | **Read** — already uses `renderComponentHtml(faqSection)` (fixed) |

**Risk:** Low. Already migrated to `renderComponentHtml()`.

### Pipeline Legacy Stages

| File | Lines | Access Type |
|---|---|---|
| `blog-generation-pipeline.ts` | 133 | **Render** — `state.blog = renderArticleDocument(state.articleDoc)` |
| `blog-generation-pipeline.ts` | 216, 222–223 | **Read** — `state.blog` for word count (text analysis) |
| `blog-generation-pipeline.ts` | 570–577 | **Read/Write** — factual-scan: `section.html → cleanedHtml → section.blocks` |
| `blog-generation-pipeline.ts` | 620–636 | **Read/Write** — final-trim: `sectionHtml → trimmedHtml → section.blocks` |
| `blog-generation-pipeline.ts` | 770 | **Read** — deriveSectionInput: `s.html → renderComponentHtml(s)` |
| `blog-generation-pipeline.ts` | 813, 838 | **Write** — expansion/trim results → `section.blocks` |

**Risk:** Low. All pipeline stages already go through the controlled bridge (render → process → parse → validate → commit).

### SEO Normalisation (temporary HTML compatibility path)

| File | Lines | Access Type |
|---|---|---|
| `final-seo-normalizer.ts` | 930–949 | **Read/Write** — `firstBlock.html` edited as HTML string |

**Risk:** Low (hidden dependency). The `firstBlock.html` reference was discovered during the audit — it edits the HTML of an editable component returned by `extractEditableContent`. Must use `renderComponentHtml()` read → edit string → `parseWordPressEditorialBlocks()` write → assign `blocks`.

### Generation Service Cleanup

| File | Lines | Access Type |
|---|---|---|
| `blog-generation-service.ts` | 386, 392, 406 | **Write** — stores blocks by rendering → `parseWordPressEditorialBlocks` round trip |

**Risk:** Medium. The service should store `normalizeAiEditorialPayload().blocks` directly instead of rendering → parsing back.

### Test Fixtures

| File | Lines | Access Type |
|---|---|---|
| `blog-generation-pipeline.test.ts` | 265, 274 | **Assertion** — expects `.html` on parsed result |
| `final-seo-normalizer.test.ts` | 3538, 3539, 3547, 5248, 5251, 5259, 5262 | **Assertion/Write** — creates and checks `.html` on components |
| `verify-word-count-tiers.test.ts` | Multiple | **Construction** — `makeDocWithSections` uses `{ html: string, wordCount: number }` |

**Risk:** Low. Test-only code. All failures block the full test suite but do not affect production. Requires updating fixture helpers to construct `EditorialBlock[]` instead of `html` strings.

## Current Test Count

**944 passing, 0 failing** (13 test files).

## Current Build Status

- **Turbopack compilation**: ✅ Passes
- **TypeScript type checking**: ✅ Passes — all production code errors resolved. Remaining type errors in `article-content.test.ts` (6), `final-seo-normalizer.test.ts` (17), and `regression-issues.test.ts` (4) are all pre-existing and unrelated to structured-content migration.

## Agreed Implementation Order

| Step | Action | Risk |
|---|---|---|
| 1 | Add compatibility adapters (`renderComponentHtml` exists; add `htmlToBlocks` if needed) | None |
| 2 | Replace editorial HTML **reads** with `renderComponentHtml()` in translation-service, SEO normalizer | Low |
| 3 | Parse editorial HTML **writes** with `parseWordPressEditorialBlocks()` in translation-service, SEO normalizer | Low |
| 4 | Validate and roll back invalid legacy-stage output | Already done in `runTrackedHtmlStage` |
| 5 | Remove `html?` from `ArticleComponent` | Already done |
| 6 | Remove renderer fallback (`renderComponent` function that checked `.html`) | Already done |
| 7 | Store generated blocks directly (eliminate HTML → parse5 round trip in service) | Medium |
| 8 | Update test fixtures to use `EditorialBlock[]` | Low |
| 9 | Run complete test suite and build | — |

## Current Architectural Rules (Never Break)

1. **`EditorialBlock[]` is canonical.** Content is stored as typed block arrays. No editorial component may have both `html` and `blocks`.
2. **`state.articleDoc` is canonical.** All pipeline stages mutate it. `state.blog` is only a rendered cache, regenerated from `articleDoc` after every commit.
3. **AI never owns CTA.** CTA is injected by the pipeline's `cta-preserve` stage from a constant canonical HTML string.
4. **Legacy HTML stages must be wrapped.** The controlled bridge: render → legacy process → parse → validate → commit. On parse failure, restore pre-stage document.
5. **No non-null assertions on parser results.** `parseArticleDocumentFromHtml().doc!` is forbidden.
6. **The renderer is the only source of WordPress markup.** `renderEditorialBlocksToWordPress` — no manual WP comment construction.
7. **No regex-based WordPress repair.** The `fp()` flatten function is the only exception and is being phased out.
8. **Conclusion content comes from conclusion blocks only.** Never extracted from the last editorial section via pattern matching.
9. **Translation and SEO normalisation are temporary HTML compatibility paths.** They should later operate directly on `EditorialBlock[]` text nodes.
