# Next Chat Handoff

## Opening Message for Future ChatGPT Session

```
I am continuing the B2I Content Engine structured-content migration.

State when my session ended:
- Build: Turbopack compilation passes, but TypeScript type-checking fails (~30 errors).
- Tests: 851 passing, 32 failing (all in test fixture helpers that use old { html, wordCount } format).
- The ArticleComponent type has had its `html` field removed — `.html` is no longer valid on editorial components.
- Most production code has been migrated. Remaining .html references are:

  Translation reads (9): translation-service.ts L263, 264, 296, 311, 312, 368, 386, 387, 412
  Translation writes (1): translation-service.ts L430 (faqSection.html = faqBody)
  SEO normalizer (5): final-seo-normalizer.ts L930, 932, 934, 938, 949 (firstBlock.html)
  Test fixtures (~25): blog-generation-pipeline.test.ts, final-seo-normalizer.test.ts, verify-word-count-tiers.test.ts

The exact next step is listed below. Please pick up from there.
```

## Current Architecture (Quick Reference)

```
AI → {"blocks":[...]} → normalizeAiEditorialPayload → EditorialBlock[]
→ ArticleDocument (stores blocks exclusively)
→ renderEditorialBlocksToWordPress (only at render time)
→ legacy bridge: render → process → parse → validate → commit
```

### Data Flow Detail

| Step | What Happens | Canonical State |
|---|---|---|
| AI generation | Returns `{"blocks": [...]}` JSON | None |
| Normalization | `normalizeAiEditorialPayload` validates + transforms | EditorialBlock[] |
| Storage | Directly into `ArticleComponent.blocks` | ✅ `state.articleDoc` |
| Rendering | `renderEditorialBlocksToWordPress()` | `state.blog` (cache) |
| Legacy processing | HTML → processor → new HTML | Cache only |
| Parsing | `parseWordPressEditorialBlocks()` → blocks | ✅ `state.articleDoc` |

### Key Files

| File | Purpose |
|---|---|
| `src/lib/blog/article-content.ts` | Types (`EditorialBlock`, `InlineContent`), normalizer, renderer, parser (parse5) |
| `src/lib/blog/article-document.ts` | `ArticleDocument` type (no `.html` on editorial), render function, parser |
| `src/lib/pipeline/blog-generation-pipeline.ts` | Pipeline stages, legacy bridge (`runTrackedHtmlStage`) |
| `src/lib/services/blog-generation-service.ts` | Generates AI content, assembles ArticleDocument |
| `src/lib/services/translation-service.ts` | Translation — **temporary HTML compatibility path** — still uses `.html` |
| `src/lib/blog/final-seo-normalizer.ts` | SEO normalizer — **temporary HTML compatibility path** — still uses `.html` |
| `src/lib/services/translation-assembler.ts` | FAQ extraction — already uses `renderComponentHtml` |

## What Has Already Been Completed

- `EditorialBlock[]` types, normalizer, renderer, parser (parse5) — all in `article-content.ts`
- `ArticleComponent` type updated — `.html` field removed, `blocks: EditorialBlock[]` is canonical
- `renderArticleDocument` — uses `renderEditorialBlocksToWordPress` for all editorial
- `parseArticleDocumentFromHtml` — uses `parseWordPressEditorialBlocks` to reconstruct blocks
- Stable markers: `<!-- b2i-conclusion-start -->`, `<!-- b2i-conclusion-end -->`, `<!-- b2i-faq-heading -->`
- FAQ heading detected by marker, not by Chinese substring
- `validateFaqParity` uses JSON.parse with `@type === "FAQPage"`
- `state.faq` synced from `articleDoc.visibleFaq` in `syncBlogFromDocument` + `createPipelineState`
- Conclusion prompt de-CTA'd (no CTA module in conclusion system prompt)
- Service-level retry tests: 13 tests with injected `requestDeepSeek` mock
- Default prompts updated for structured JSON blocks
- Pipeline legacy bridge: render → process → parse → validate → commit with snapshot rollback
- `runTrackedHtmlStage` enforces: no `.doc!` non-null assertions, rollback on parse failure

### Audit Completed

A full repository-wide `.html` dependency audit was performed. Every `.html` access on editorial `ArticleComponent`/`ArticleSection` objects was catalogued. Results are in `02_STRUCTURED_CONTENT_MIGRATION.md`.

**Hidden dependency discovered:** `firstBlock.html` in `final-seo-normalizer.ts` line 930 — the SEO normalizer edits component HTML directly through an intermediary `EditableArticleContent` object. This was not visible from `ArticleDocument`.

## Current Test/Build Baseline (Final)

- **Tests:** **944 passing, 0 failing** (13 test files)
- **Build:** ✅ Compiles and builds successfully. TypeScript type-checking passes in production code.
- **FAQ parity validator strengthened:** Empty questions and answers are now correctly rejected. 7 regression tests added.
- **Production `.html` references eliminated:** Zero editorial `.html` or `.wordCount` remain on `ArticleComponent`/`ArticleSection` in production code or test fixtures. CTA, FAQ schema, and language switcher `.html` remain on `ProtectedArticleBlock` (intentional).

## Current Risks (Checkpoint Complete)

All migration-stage risks resolved. Remaining improvement opportunities (non-blocking):

1. **Translation service** uses `renderComponentHtml()` HTML bridge — should translate `InlineContent[].text` directly.
2. **SEO normalizer** edits HTML strings — should edit `EditorialBlock.content[i].text` directly.
3. **Service round-trip** — `blog-generation-service.ts` does render→parse round trip; should store `normalized.blocks` directly.

## Remaining `.html` Dependencies (Complete Inventory)

### Translation Reads ✅ Complete

All 9 read references in `translation-service.ts` (lines 263, 264, 296, 311, 312, 368, 386, 387, 412) have been migrated to `renderComponentHtml()` or structured-block equivalents. Zero editorial `.html` reads remain.

### Translation Writes ✅ Resolved

The dead `faqSection.html = faqBody` and `faqSection.wordCount` assignments were removed. `visibleFaq` is the sole canonical FAQ representation. FAQ section blocks must not duplicate `visibleFaq`.

### SEO Normalizer

| File | Line | Current Code | Replace With |
|---|---|---|---|
| `final-seo-normalizer.ts` | 930 | `firstBlock.html.indexOf(sentences[0])` | `const fbHtml = renderComponentHtml(firstBlock); fbHtml.indexOf(...)` |
| `final-seo-normalizer.ts` | 932 | `firstBlock.html.substring(...)` | `fbHtml.substring(...)` |
| `final-seo-normalizer.ts` | 934 | `firstBlock.html.substring(...)` | `fbHtml.substring(...)` |
| `final-seo-normalizer.ts` | 938 | `firstBlock.html.replace(...)` | `fbHtml.replace(...)` |
| `final-seo-normalizer.ts` | 949 | `html.replace(firstBlock.html, () => modified)` | After computing `modified`, parse: `firstBlock.blocks = parseWordPressEditorialBlocks(modified, firstBlock.id).blocks` |

### Test Fixtures

| File | Lines | Issue |
|---|---|---|
| `blog-generation-pipeline.test.ts` | 265, 274 | `parseResult.doc.introduction.html` → `.blocks` |
| `final-seo-normalizer.test.ts` | 3538, 3539, 3547 | `doc.conclusion.html` → `.blocks` |
| `final-seo-normalizer.test.ts` | 5248, 5251, 5259, 5262 | `doc.introduction.html = ...` → use `parseWordPressEditorialBlocks` |
| `verify-word-count-tiers.test.ts` | Multiple | `{ html: string, wordCount: number }` → `{ blocks: EditorialBlock[] }` |

## Protected HTML (Do Not Touch)

| Field | Purpose | Why Protected |
|---|---|---|
| `languageSwitcher.html` | EN/ZH slug toggle | Deterministic, application-owned, never AI-generated |
| `cta.html` | Signup call-to-action | Application-owned, injected by `cta-preserve` stage, constant canonical HTML |
| `faqSchema.html` | FAQPage JSON-LD | Generated from `visibleFaq` by `renderFaqSchema()`, application-owned |
| `visibleFaq` | FAQ Q&A entries | Structured, synced to `state.faq` for persistent |
| Rendered `state.blog` | Full article HTML | Output of `renderArticleDocument()`, regenerated after each commit |

**Editorial component HTML is NOT persisted to the database.** The database stores `blog` (fully rendered HTML), `faq` (structured pairs), and metadata. `ArticleDocument` is in-memory only.

## Migration Checkpoint Reached — 2026-07-28

All tracked objectives for the structured-content migration checkpoint are complete:

- ✅ All editorial `.html`/`.wordCount` accesses removed from production code
- ✅ All 3 test files migrated to `EditorialBlock[]` fixtures
- ✅ `validateFaqParity` strengthened (empty Q/A rejected + 7 regression tests)
- ✅ Remaining TypeScript errors fixed (`FinalArticleMetrics`, readonly keyphrase, `word_count`)
- ✅ **944 tests passing, 0 failing**
- ✅ **Production build green**

### Next Phase: Translation Structured-Text-Node

The next migration phase should translate `InlineContent[].text` directly instead of rendering HTML → protecting numbers in HTML → translating HTML → parsing back to blocks. This eliminates the remaining HTML compatibility path in `translation-service.ts`.

### Future Phases (ordered by risk)

1. Fix service round-trip — store `normalized.blocks` directly in `blog-generation-service.ts`
2. Migrate SEO normalizer from HTML string editing to `EditorialBlock[]` mutation

## Files to Inspect First

1. `src/lib/services/translation-service.ts` — ✅ Done — Zero editorial `.html` references remain
2. `src/lib/blog/final-seo-normalizer.ts` — `firstBlock.html` hidden dependency (5 references)
3. `src/lib/services/blog-generation-service.ts` — Service round-trip elimination
4. `src/lib/pipeline/blog-generation-pipeline.test.ts` — Test fixture update (lines 265, 274)
5. `src/lib/blog/final-seo-normalizer.test.ts` — Test fixture update (7 references)
6. `src/lib/pipeline/verify-word-count-tiers.test.ts` — Test fixture update (`makeDocWithSections`)

## Architectural Rules (Never Break)

- `EditorialBlock[]` is canonical. No editorial component may have both `html` and `blocks`.
- `state.articleDoc` is the single source of truth. `state.blog` is a rendered cache only.
- `state.blog` must always be regenerated from `articleDoc` after every committed change.
- Never use non-null assertions on `parseArticleDocumentFromHtml` results (`.doc!` is forbidden).
- The legacy bridge must roll back on parser failure.
- AI must never generate CTA content. CTA is application-owned.
- The renderer (`renderEditorialBlocksToWordPress`) is the only source of WordPress markup.
- No regex-based WordPress repair.
- No raw prose outside supported WordPress blocks.
- Conclusion content comes from conclusion blocks only — never from the last editorial section.
- **Translation and SEO normalisation are temporary HTML compatibility paths.** They should later operate directly on `EditorialBlock[]` text nodes.

## Established Test Helper Patterns

The following helpers are now used in `blog-generation-pipeline.test.ts` and can be reused:

```ts
import { parseWordPressEditorialBlocks, renderComponentHtml } from "@/lib/blog/article-document";

function componentFromHtml(id: string, html: string, status: ComponentStatus = "generated"): ArticleComponent {
  const parsed = parseWordPressEditorialBlocks(html, id);
  expect(parsed.errors).toEqual([]);
  return { id, blocks: parsed.blocks, status };
}
function sectionFromHtml(id: string, heading: string, html: string, sectionType: "main" | "faq-heading" | "conclusion-heading" = "main", status: ComponentStatus = "generated"): ArticleSection {
  const parsed = parseWordPressEditorialBlocks(html, id);
  expect(parsed.errors).toEqual([]);
  return { id, heading, headingLevel: 2, sectionType, blocks: parsed.blocks, status };
}
```
    conclusion: { id: "conc", blocks: parseWordPressEditorialBlocks(concHtml, "conc").blocks, status: "generated" },
    // ... cta, faqSchema, visibleFaq, insertedLinks
  };
}
```
