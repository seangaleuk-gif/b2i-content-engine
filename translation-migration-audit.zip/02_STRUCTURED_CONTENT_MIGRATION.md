# Structured Content Migration

## Original HTML-First Architecture

Before the migration, `ArticleDocument` stored editorial content as raw WordPress HTML strings:

```ts
interface ArticleComponent {
  id: string;
  html: string;        // WordPress HTML like "<!-- wp:paragraph --><p>Content</p><!-- /wp:paragraph -->"
  wordCount: number;
  status: ComponentStatus;
}
```

AI responses were expected to return full WordPress HTML with `<!-- wp:* -->` block comments. The generation pipeline accepted AI-generated HTML, attempted regex-based repair (`rebalanceWpBlocks`, `stripHeadingBlocks`), and stored the result directly. The parser (`parseArticleDocumentFromHtml`) extracted HTML from rendered articles and stored it back as `.html` strings.

Problems with the old approach:
- AI-generated HTML frequently had malformed block comments, nested `<p>` tags, and orphaned markers.
- Regex-based repair was fragile and could produce `wp:wp:paragraph` artifacts.
- No structured content validation existed — AI could generate H2s, CTA content, or raw prose anywhere.
- FAQ recovery scanned raw HTML and frequently absorbed conclusion/CTA text into FAQ answers.

## Target Structured-Content Architecture

### Canonical Model

```ts
interface ArticleComponent {
  id: string;
  blocks: EditorialBlock[];  // structured typed blocks
  status: ComponentStatus;
}
```

`EditorialBlock` is a discriminated union:

```ts
type EditorialBlock =
  | { id: string; type: "paragraph"; content: InlineContent[] }
  | { id: string; type: "subheading"; level: 3; content: InlineContent[] }
  | { id: string; type: "list"; ordered: boolean; items: InlineContent[][] }
  | { id: string; type: "quote"; content: InlineContent[] }
  | { id: string; type: "table"; headers: InlineContent[][]; rows: InlineContent[][][] };
```

### Data Flow

```
AI (DeepSeek) → {"blocks": [...]} JSON
  → normalizeAiEditorialPayload() validates and transforms
  → EditorialBlock[] stored directly in ArticleDocument
  → renderEditorialBlocksToWordPress() produces WP HTML (only at render time)
  → parseWordPressEditorialBlocks() reconstructs blocks from legacy HTML (only at legacy bridge boundary)
```

### No Round-Trip Between AI and Storage

Generated blocks are stored directly. The service must NOT render → then parse → then store. `parseWordPressEditorialBlocks` is used only for:
- Legacy HTML reconstruction (existing published articles)
- Temporary HTML-stage bridge output
- Translation output that arrives as WordPress HTML

## Completed Migration Stages

| # | Stage | Key Files Changed |
|---|---|---|
| 1 | Create `EditorialBlock` / `InlineContent` types | `article-content.ts` |
| 2 | Create `normalizeAiEditorialPayload` with validation | `article-content.ts` |
| 3 | Create `renderEditorialBlocksToWordPress` | `article-content.ts` |
| 4 | Add `parseWordPressEditorialBlocks` (parse5 DOM parser) | `article-content.ts` |
| 5 | Add CTA-scoped rejection option | `article-content.ts` (NormalizationOptions) |
| 6 | Add `validateEditorialBlocks`, `extractPlainText`, `countWords`, `clone` | `article-content.ts` |
| 7 | Update `ArticleDocument` — remove `html`, add `blocks` | `article-document.ts` |
| 8 | Update `renderArticleDocument` to use `renderEditorialBlocksToWordPress` | `article-document.ts` |
| 9 | Update `parseArticleDocumentFromHtml` | `article-document.ts` (uses parse5 parser) |
| 10 | Add conclusion markers, FAQ heading marker | `article-document.ts` |
| 11 | Update pipeline: `renderComponentHtml`/`parseWordPressEditorialBlocks` bridge | `blog-generation-pipeline.ts` |
| 12 | Update service: store blocks, parse legacy HTML | `blog-generation-service.ts` |
| 13 | Update service: seed `visibleFaq` from FAQ section | `blog-generation-service.ts` |
| 14 | Update service-level tests with DI mock | `blog-generation-service.test.ts` |
| 15 | Update default prompts for structured JSON | `default-prompts.ts`, `prompt-builder.ts` |
| 16 | Update translation route minimal doc | `translate/route.ts` |
| 17 | Partial update translation-service / assembler | `translation-service.ts`, `translation-assembler.ts` |
| 18 | Add `parse5` + `@types/parse5` | `package.json` |

## Repository-Wide `.html` Dependency Audit

### Audit Methodology

Every non-test `.ts` file was searched for `.html` access on `ArticleComponent`/`ArticleSection` objects. Each occurrence was categorized by:
- File, function/type name, line number
- Whether it reads, writes, transforms, persists, or renders `.html`
- Migration category

### Grouped Findings

#### 1. Translation (temporary HTML compatibility path)

| File | Lines | Access | Action | Risk | Migration Decision |
|---|---|---|---|---|---|
| ~~`translation-service.ts`~~ | ~~263~~ | ~~`enDoc.introduction.html` (read)~~ | **Fixed** — uses `renderComponentHtml()` | — | |
| ~~`translation-service.ts`~~ | ~~264~~ | ~~`protectNumbersInHtml(enDoc.introduction.html)` (read)~~ | **Fixed** — uses `renderComponentHtml()` | — | |
| ~~`translation-service.ts`~~ | ~~296~~ | ~~`enDoc.introduction.html` fallback (read)~~ | **Fixed** — uses `renderComponentHtml()` | — | |
| ~~`translation-service.ts`~~ | ~~311, 312~~ | ~~`section.html` guard + protectNumbers (read)~~ | **Fixed** — uses `renderComponentHtml()` | — | |
| ~~`translation-service.ts`~~ | ~~368~~ | ~~`section.html` in status ternary (read)~~ | **Fixed** — uses `section.blocks.length > 0` | — | |
| ~~`translation-service.ts`~~ | ~~386, 387, 412~~ | ~~`enDoc.conclusion.html` (read)~~ | **Fixed** — uses `renderComponentHtml()` + `enConcHtml` | — | |
| ~~`translation-service.ts`~~ | ~~430~~ | ~~`faqSection.html = faqBody` (write)~~ | **Removed** — dead state; `visibleFaq` is sole canonical FAQ representation | — | |

#### 2. Translation Assembly

| File | Lines | Access | Action | Risk | Migration Decision |
|---|---|---|---|---|---|
| `translation-assembler.ts` | 22–23 | `faqSection.html` (read) | Already uses `renderComponentHtml()` | — | Fixed in a previous migration step |

#### 3. Pipeline Legacy Stages

| File | Lines | Access | Action | Risk | Migration Decision |
|---|---|---|---|---|---|
| `blog-generation-pipeline.ts` | 133 | `state.blog = renderArticleDocument(state.articleDoc)` | Uses blocks via renderer | — | Correct — cache regeneration |
| `blog-generation-pipeline.ts` | 216, 222–223 | `state.blog` word count | Text analysis via `countReadableWords` | — | Correct — works on cached HTML |
| `blog-generation-pipeline.ts` | 570–577 | Factual scan section HTML | Already uses `renderComponentHtml` + `parseWordPressEditorialBlocks` | — | Correct — legacy bridge |
| `blog-generation-pipeline.ts` | 620–636 | Final trim section HTML | Already uses `renderComponentHtml` + `parseWordPressEditorialBlocks` | — | Correct — legacy bridge |
| `blog-generation-pipeline.ts` | 770 | `deriveSectionInput` | Already uses `renderComponentHtml(s)` | — | Correct |
| `blog-generation-pipeline.ts` | 813, 838 | Expansion/trim results | Already uses `parseWordPressEditorialBlocks` | — | Correct |

#### 4. SEO Normalisation (hidden dependency, temporary compatibility path)

| File | Lines | Access | Action | Risk | Migration Decision |
|---|---|---|---|---|---|
| `final-seo-normalizer.ts` | 930 | `firstBlock.html.indexOf(sentences[0])` (read) | Replace with `renderComponentHtml()` | Low | Hidden dependency discovered during audit; normalizer edits HTML strings directly |
| `final-seo-normalizer.ts` | 932, 934 | `firstBlock.html.substring(...)` (read) | Replace with `renderComponentHtml()` | Low | |
| `final-seo-normalizer.ts` | 938 | `firstBlock.html.replace(...)` (read) | Replace with `renderComponentHtml()` | Low | |
| `final-seo-normalizer.ts` | 949 | `html.replace(firstBlock.html, ...)` (write) | Replace with `parseWordPressEditorialBlocks()` | Low | After editing the rendered string, parse back to blocks |

The `firstBlock` variable is an `ArticleComponent` returned by `extractEditableContent()`. This was not discovered in earlier searches because the component is accessed through an intermediary object, not directly from `ArticleDocument`.

#### 5. Generation Service Cleanup

| File | Lines | Access | Action | Risk | Migration Decision |
|---|---|---|---|---|---|
| `blog-generation-service.ts` | 386 | `blocks: parseWordPressEditorialBlocks(intro, "intro").blocks` | Store normalized blocks directly | Low | Currently renders AI output to HTML → parses back. Should store `normalized.blocks` directly. |
| `blog-generation-service.ts` | 392 | `blocks: parseWordPressEditorialBlocks(s.body, ...).blocks` | Same | Low | |
| `blog-generation-service.ts` | 406 | `blocks: parseWordPressEditorialBlocks(conclusion, "conc").blocks` | Same | Low | |

#### 6. Test Fixtures

| File | Lines | Access | Risk |
|---|---|---|---|
| `blog-generation-pipeline.test.ts` | 265, 274 | `parseResult.doc.introduction.html` / `.conclusion.html` assertions | Low |
| `final-seo-normalizer.test.ts` | 3538, 3539, 3547 | `doc.conclusion.html` assertions | Low |
| `final-seo-normalizer.test.ts` | 5248, 5251, 5259, 5262 | `doc.introduction.html = ...` / assertions | Low |
| `verify-word-count-tiers.test.ts` | Multiple | `makeDocWithSections` creates `{ html: string, wordCount: number }` | Low |

All test fixtures need `EditorialBlock[]` construction instead of `html` strings.

### Hidden Dependencies Found

1. **`firstBlock.html` in `final-seo-normalizer.ts`**: The SEO normalizer's `ensureKeyphraseInFirst100Words` function receives an `EditableArticleContent` object and edits `firstBlock.html` directly. This is a legacy HTML operation that must go through the controlled bridge.

2. ~~**`faqSection.html = faqBody` in `translation-service.ts`**~~: **Resolved.** The FAQ section body assignments were obsolete dead state — `renderArticleDocument()` renders FAQ content exclusively from `doc.visibleFaq`, not from section blocks. The dead assignments were removed. `visibleFaq` is the sole canonical FAQ representation.

### Confirmed Not Persisted

ArticleComponent HTML is not directly persisted to the database. The database stores:
- `blog: string` — full rendered HTML via `renderArticleDocument()`
- `faq: Array<{ question, answer }>` — structured Q&A pairs
- Metadata fields (title, slug, meta, excerpt)

`ArticleDocument` is an in-memory model reconstructed on each generation or parse operation.

## Agreed Implementation Order

| # | Step | Details | Testing |
|---|---|---|---|
| 1 | Add compatibility adapters | `renderComponentHtml()` exists. Consider `htmlToBlocks(html, id)` as a symmetric write helper. | Build only |
| 2 | Replace editorial HTML reads with `renderComponentHtml()` | Translation service, SEO normalizer. | Build passes |
| 3 | Parse editorial HTML writes with `parseWordPressEditorialBlocks()` | Translation service `faqSection.html = faqBody`, SEO normalizer `html.replace(firstBlock.html, ...)`. | Build passes |
| 4 | Validate and roll back invalid legacy-stage output | Already implemented in `runTrackedHtmlStage` (snapshot + restore). | Already tested |
| 5 | Remove `html?` from `ArticleComponent` | ✅ Already done. Will re-verify TypeScript strictness after other steps. | TypeScript check |
| 6 | Remove renderer fallback | ✅ Already done. `renderArticleDocument` uses only `renderEditorialBlocksToWordPress`. | Render tests |
| 7 | Store generated blocks directly | Service stores `normalizeAiEditorialPayload().blocks` without HTML round trip. | Generation tests |
| 8 | Update test fixtures | Convert `{ html: string }` to `{ blocks: EditorialBlock[] }` in all helpers. | Full test suite |
| 9 | Run complete test suite and build | All 880+ tests passing, TypeScript strict mode passes. | Final gate |

## Controlled Legacy Bridge

Processors that still require HTML operate through a controlled render → process → parse → validate → commit bridge:

```
ArticleDocument.blocks
  → renderArticleDocument()            # produce full HTML
  → renderComponentHtml(section)       # produce single component HTML
  → legacy processor (normalizer, factual-scan, trim, expand, etc.)
  → parseWordPressEditorialBlocks()    # reconstruct blocks from HTML
  → ArticleDocument.blocks
  → validate and commit or rollback
```

Rules enforced by `runTrackedHtmlStage`:
1. Snapshot `state.articleDoc` before the stage.
2. Render to `state.blog`.
3. Pass HTML to the legacy stage.
4. Parse the result back via `parseArticleDocumentFromHtml`.
5. If parsing fails (null doc), restore the pre-stage snapshot.
6. If parsing succeeds, commit the new doc and regenerate `state.blog`.
7. Never use non-null assertions on parser results.

### Why the Bridge Is Needed

The following processors have not yet been migrated to structured blocks and require the bridge:

- **SEO normalizer** (`final-seo-normalizer.ts`) — edits component HTML strings directly
- **Factual scan** (`factual-risk-scanner.ts`) — removes unsupported sentences from HTML
- **Final trim** — removes last paragraph from sections when over word limit
- **Expansion/trim** (`section-expander.ts`) — adds/removes content from sections
- **Claim check** (`component-regenerator.ts`) — regenerates sections via AI

All of these go through `runTrackedHtmlStage` and correctly render → process → parse → validate → commit.

## Long-Term Architecture

When all processors have been migrated to structured blocks:

```
EditorialBlock[]
  → renderEditorialBlocksToWordPress()  (only at final publishing)
  → WordPress HTML blog post
```

No intermediate HTML processing, no regex repair, no re-parsing. The only render call is at the publishing boundary.

**Translation and SEO normalisation are temporary HTML compatibility paths.** They should later operate directly on `EditorialBlock[]` text nodes — the SEO normalizer should edit `EditorialBlock.content[i].text` instead of rendered HTML strings, and the translation service should translate `InlineContent[].text` fields instead of WordPress HTML.

## Migration Checkpoint — 2026-07-28

The structured-content migration is checkpoint-complete:

- **ArticleComponent** stores only `blocks: EditorialBlock[]` — no `.html` or `.wordCount`
- **ArticleDocument** is the sole canonical editorial state; `state.blog` is a rendered cache
- **`renderArticleDocument()`** uses `renderEditorialBlocksToWordPress()` exclusively
- **`parseArticleDocumentFromHtml()`** uses `parseWordPressEditorialBlocks()` 
- **Legacy HTML bridge** (render → process → parse → validate → commit) wraps all remaining HTML-stage processors
- **`validateFaqParity()`** correctly rejects empty questions and answers
- **944 tests passing, 0 failing**, production build green

### Remaining Future Work

| Item | Priority |
|---|---|
| Migrate `blog-generation-service.ts` service round-trip (store `normalized.blocks` directly) | Medium |
| Migrate `final-seo-normalizer.ts` from HTML mutation to `EditorialBlock[]` mutation | Medium |
| Migrate translation service from `InlineContent.text` HTML bridge to direct structured-text translation | Low |
