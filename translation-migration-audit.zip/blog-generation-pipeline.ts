// ── Canonical blog generation pipeline ──
// All post-assembly stages extracted from route.ts.
// route.ts handles auth, section generation, initial assembly, then delegates here.
//
// ArticleDocument is the single canonical mutable source.
// state.blog is ONLY assigned by syncBlogFromDocument() — never directly.
// No stage treats raw HTML as independently canonical.

import type { ArticleDocument } from "@/lib/blog/article-document";
import { renderArticleDocument, fingerprintHtml, detectClaimConflicts, parseArticleDocumentFromHtml, detectNestedParagraphs, renderFaqSchema, validateFaqParity, CONCLUSION_START_MARKER, CONCLUSION_END_MARKER, extractVisibleFaqFromArticle, renderComponentHtml, parseWordPressEditorialBlocks } from "@/lib/blog/article-document";
import { type FinalSeoNormalizerResult } from "@/lib/blog/final-seo-normalizer";
import { normalizeFinalSeo } from "@/lib/blog/final-seo-normalizer";
import {
  createArticleIntegrityBaseline,
  validateFinalArticleIntegrity,
  validateWordpressBlockPairs,
  type ArticleIntegrityBaseline,
} from "@/lib/blog/article-integrity";
import type { FinalArticlePolicy, FinalArticleMetrics } from "@/lib/blog/final-article-policy";
import { buildPolicy, analyzeFinalArticle, evaluatePolicy } from "@/lib/blog/final-article-policy";
import { countReadableWords, containsExactPhrase } from "@/lib/services/text-utils";
import { extractReadableText, getFirstNReadableWords, extractH2Texts, extractParagraphTexts, countSentences, countCtaHeadingTags } from "@/lib/seo/seo-text-utils";
import { MAX_SENTENCES_PER_PARAGRAPH } from "@/lib/services/generation-constants";
import { dynamicFaqRange } from "@/lib/content-standards";
import { insertExternalResearchLinks, deduplicateEditorialExternalLinks, ensureLanguageSwitcher, pairedSlugs } from "@/lib/services/article-postprocessors";
import { expandToMinimum, trimToMaximum, normalizeParagraphs } from "@/lib/services/section-expander";
import { runComponentRegeneration, regenerateSection } from "@/lib/services/component-regenerator";
import { scanFactualRisks, removeUnsupportedSentences, formatClaimLog } from "@/lib/blog/factual-risk-scanner";
import { enforceInternalLinkLimit } from "@/lib/blog/final-article-policy";

/** Enumerate individual wp:html blocks and select the one whose parsed JSON-LD type is FAQPage. */
function extractFaqBlockForPipeline(html: string): string | null {
  const wpHtmlRe = /<!--\s*wp:html\s*-->([\s\S]*?)<!--\s*\/wp:html\s*-->/gi;
  let whm: RegExpExecArray | null;
  while ((whm = wpHtmlRe.exec(html)) !== null) {
    const inner = whm[1];
    if (/FAQPage/.test(inner)) {
      // Verify it's actually parseable as FAQPage JSON-LD
      const scriptMatch = inner.match(/<script[^>]*>([\s\S]*?)<\/script>/i);
      if (scriptMatch) {
        try {
          const parsed = JSON.parse(scriptMatch[1]);
          if (parsed?.["@type"] === "FAQPage") return whm[0];
        } catch {
          // Not valid JSON — skip this block
        }
      }
    }
  }
  return null;
}

const CANONICAL_CTA_HTML = `<!-- wp:html -->
<div style="background: #1E3A8A; color: #fff; padding: 32px 28px; border-radius: 12px; margin: 40px 0; text-align: center;">
  <h2 style="color: #fff; margin-top: 0; font-size: 22px;">Ready to grow your brand with Hong Kong creators?</h2>
  <p style="font-size: 16px; line-height: 1.6; margin-bottom: 24px;">B2I Hub connects businesses directly with verified creators — no agencies, no commissions, no middlemen. Create your free profile and start collaborating today.</p>
  <a href="https://app.b2ihub.com/signup" style="display: inline-block; background: #F97316; color: #fff; padding: 14px 36px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 16px;" target="_blank" rel="noopener">Create Your Free Profile →</a>
</div>
<!-- /wp:html -->`;

// ── Types ──

export interface PipelineStageOutput {
  stage: string;
  inputFingerprint: string;
  outputFingerprint: string;
  accepted: boolean;
  fallbackSource?: string;
  metadata?: Record<string, unknown>;
}

export interface PipelineState {
  readonly userId: string;
  readonly projectId: string;
  readonly keyphrase: string;
  readonly requestedWordCount: number;
  blog: string;
  title: string;
  slug: string;
  metaDescription: string;
  excerpt: string;
  faq: Array<{ question: string; answer: string }>;
  internalLinks: any[];
  externalLinks: any[];
  categories: string[];
  tags: string[];
  readingTime: string;
  summary: string;
  articleDoc: ArticleDocument;
  stageOutputs: PipelineStageOutput[];
  h2Headings: string[];
  intro: string;
  conclusion: string;
  wordsPerSection: number;
  exactKeyphraseTarget: number;
  retryCount: number;
  componentRegenerations: number;
  warnings: string[];
  startTime: number;
  normalizationResult: FinalSeoNormalizerResult | null;
  normalizationAccepted: boolean;
  qualityReport: any | null;
  policy: FinalArticlePolicy;
  ctx: any;
  baseline: ArticleIntegrityBaseline | null;
  wordMin: number;
  wordMax: number;
  estimatedTokens: number;
  systemPrompt: string;
  userMessage: string;
  currentWordCount: number;
  expansionAttempts: number;
  trimAttempts: number;
}

// ── Pipeline dependencies ──

export interface PipelineDependencies {
  chatWithRetry: any;
  makeTrackedChatForStage: (stage: string) => any;
  telemetry: any;
  context: any;
}

// ── Helpers ──

function fp(html: string): string { return fingerprintHtml(html); }

/** THE ONLY place state.blog is assigned. No other code may assign state.blog directly.
 *  Also synchronizes state.faq from articleDoc.visibleFaq so the database FAQ field,
 *  visible FAQ and schema all contain the same entries. */
function syncBlogFromDocument(state: PipelineState): void {
  state.blog = renderArticleDocument(state.articleDoc);
  state.faq = state.articleDoc.visibleFaq.map((e) => ({
    question: e.question,
    answer: e.answerText,
  }));
}

/** Derive section input from the canonical ArticleDocument. */
function deriveSectionInput(state: PipelineState): Array<{ index: number; heading: string; body: string }> {
  return state.articleDoc.sections.map((s, i) => ({
    index: i, heading: s.heading, body: renderComponentHtml(s),
  }));
}

// ── Validation ──

interface StageValidationResult {
  valid: boolean; nestedParagraphs: number; malformedHeadings: number;
  wpBlocksValid: boolean; unclosedTags: string[]; issues: string[];
}

function runStageValidation(html: string, baseline: ArticleIntegrityBaseline, stage: string): StageValidationResult {
  const result = validateFinalArticleIntegrity(html, baseline);
  const unclosed = result.errors.filter((e) => e.startsWith("Unclosed HTML tags"));
  const unclosedTags = unclosed.length > 0 ? [unclosed[0]] : [];
  const wpPairResult = validateWordpressBlockPairs(html);
  const wpBlocksValid = wpPairResult.valid;
  const issues: string[] = [...result.errors];
  for (const wpIssue of wpPairResult.issues) issues.push(wpIssue);
  return { valid: result.valid && wpBlocksValid, nestedParagraphs: result.metrics.nestedParagraphCount,
    malformedHeadings: result.metrics.malformedHeadingCount, wpBlocksValid, unclosedTags, issues };
}

function logValidationFailure(
  stage: string,
  label: "Candidate" | "Fallback",
  html: string,
  validation: StageValidationResult,
): void {
  const entry = {
    htmlLength: html.length,
    fingerprint: fp(html),
    valid: validation.valid,
    wpBlocksValid: validation.wpBlocksValid,
    nestedParagraphs: validation.nestedParagraphs,
    malformedHeadings: validation.malformedHeadings,
    unclosedTags: validation.unclosedTags,
    issues: validation.issues,
  };
  console.error(`[PIPELINE:${stage}] ${label} validation failed`);
  console.error(JSON.stringify(entry, null, 2));
}

function formatIssueSummary(validation: StageValidationResult, maxIssues = 5): string {
  const count = validation.issues.length;
  const shown = validation.issues.slice(0, maxIssues);
  let summary = `${count} issue${count !== 1 ? "s" : ""}`;
  if (shown.length > 0) {
    summary += `: ${shown.join("; ")}`;
    if (count > maxIssues) summary += ` ... and ${count - maxIssues} more`;
  }
  return summary;
}

function assertValidStageInput(
  html: string,
  baseline: ArticleIntegrityBaseline,
  stageName: string,
): void {
  const validation = runStageValidation(html, baseline, stageName);
  if (!validation.valid) {
    logValidationFailure(stageName, "Candidate", html, validation);
    throw new Error(
      `Stage ${stageName} received invalid pre-stage HTML. ` +
      `${formatIssueSummary(validation)}`,
    );
  }
}

/** Remove FAQ Q&A pairs from state.articleDoc.visibleFaq until word count fits within the limit.
 *  Never trims below dynamicFaqRange(requestedWordCount).min. Syncs blog after mutation.
 *  If the article still exceeds word tolerance at the minimum FAQ count, returns false (hard fail). */
function trimFaqDirectly(state: PipelineState): boolean {
  const currentWc = countReadableWords(state.blog);
  if (currentWc <= state.wordMax) return true;
  const faqMin = dynamicFaqRange(state.requestedWordCount).min;
  // Trim from the end one entry at a time
  while (state.articleDoc.visibleFaq.length > faqMin) {
    const removed = state.articleDoc.visibleFaq.pop()!;
    renderArticleDocument(state.articleDoc); // not synced yet — just compute wc
    const newWc = countReadableWords(renderArticleDocument(state.articleDoc));
    if (newWc <= state.wordMax) {
      syncBlogFromDocument(state);
      console.log(`[faq-trim] removed entry "${removed.question.substring(0, 40)}" — new wc=${newWc}`);
      return true;
    }
  }
  // Sync the trimmed doc even if still over limit
  syncBlogFromDocument(state);
  const finalWc = countReadableWords(state.blog);
  if (finalWc > state.wordMax) {
    console.log(`[faq-trim] at minimum FAQ count (${faqMin}) still exceeds limit: ${finalWc} > ${state.wordMax} — hard fail`);
    return false;
  }
  return true;
}

export function guardStageOutput(
  currentHtml: string, previousHtml: string | null, baseline: ArticleIntegrityBaseline, stage: string,
): { html: string; accepted: boolean } {
  const validation = runStageValidation(currentHtml, baseline, stage);
  if (validation.valid) return { html: currentHtml, accepted: true };

  logValidationFailure(stage, "Candidate", currentHtml, validation);

  if (previousHtml !== null) {
    const prevValidation = runStageValidation(previousHtml, baseline, `${stage}-fallback`);
    if (prevValidation.valid) return { html: previousHtml, accepted: false };

    logValidationFailure(stage, "Fallback", previousHtml, prevValidation);

    throw new Error(
      `Stage ${stage}: both candidate and fallback invalid. ` +
      `Candidate ${formatIssueSummary(validation)}. ` +
      `Fallback ${formatIssueSummary(prevValidation)}.`,
    );
  }
  throw new Error(
    `Stage ${stage}: no fallback available, candidate invalid. ` +
    `${formatIssueSummary(validation)}`,
  );
}

export function recordStage(state: PipelineState, stageName: string, inputFp: string, outputFp: string, accepted: boolean, fallbackSource?: string, metadata?: Record<string, unknown>): void {
  state.stageOutputs.push({ stage: stageName, inputFingerprint: inputFp, outputFingerprint: outputFp, accepted, fallbackSource, metadata });
}

// ── State snapshot (articleDoc is the canonical source) ──

interface PipelineSnapshot {
  articleDoc: string;
  title: string;
  metaDescription: string;
  currentWordCount: number;
  expansionAttempts: number;
  trimAttempts: number;
  retryCount: number;
  componentRegenerations: number;
  normalizationResult: any;
  normalizationAccepted: boolean;
}

function snapshotState(state: PipelineState): PipelineSnapshot {
  return {
    articleDoc: JSON.stringify(state.articleDoc),
    title: state.title,
    metaDescription: state.metaDescription,
    currentWordCount: state.currentWordCount,
    expansionAttempts: state.expansionAttempts,
    trimAttempts: state.trimAttempts,
    retryCount: state.retryCount,
    componentRegenerations: state.componentRegenerations,
    normalizationResult: state.normalizationResult,
    normalizationAccepted: state.normalizationAccepted,
  };
}

function restoreSnapshot(state: PipelineState, snap: PipelineSnapshot): void {
  state.articleDoc = JSON.parse(snap.articleDoc);
  syncBlogFromDocument(state);
  state.title = snap.title;
  state.metaDescription = snap.metaDescription;
  state.currentWordCount = snap.currentWordCount;
  state.expansionAttempts = snap.expansionAttempts;
  state.trimAttempts = snap.trimAttempts;
  state.retryCount = snap.retryCount;
  state.componentRegenerations = snap.componentRegenerations;
  state.normalizationResult = snap.normalizationResult;
  state.normalizationAccepted = snap.normalizationAccepted;
}

// ── Stage runner: HTML-returning stages must parse back to ArticleDocument ──

function applyHtmlToDocument(state: PipelineState, html: string, existingDoc: ArticleDocument): boolean {
  const parseResult = parseArticleDocumentFromHtml(html, existingDoc);
  if (!parseResult.doc) {
    console.error(`[PIPELINE] Failed to parse HTML back to ArticleDocument: ${parseResult.errors.join("; ")}`);
    return false;
  }
  state.articleDoc = parseResult.doc;
  syncBlogFromDocument(state);
  return true;
}

function runTrackedHtmlStage(state: PipelineState, stageName: string, fn: (html: string) => string, preSnapshot?: PipelineSnapshot): PipelineState {
  // Flatten any nested <p> tags introduced by AI generation before validation.
  // Strips orphaned WordPress paragraph markers when outer <p> tags are removed.
  const fp = (html: string) => {
    // First pass: unwrap nested <p> (keep inner, drop outer <p>)
    let prev = "";
    let r = html;
    while (r !== prev) {
      prev = r;
      r = r.replace(/<p\b[^>]*>([\s\S]*?)<\/p>/g, (m, inner) => /<p\b[^>]*>/i.test(inner) ? inner : m);
    }
    // Second pass: remove wp:paragraph markers where the inner content doesn't
    // START with <p> (the <p> was stripped by pass 1, leaving orphaned markers).
    r = r.replace(
      /<!--\s*wp:paragraph\s*-->([\s\S]*?)<!--\s*\/wp:paragraph\s*-->/gi,
      (m, inner) => /^\s*<p\b[^>]*>/i.test(inner) ? m : inner,
    );
    // Third pass: repair any wp:wp:paragraph artifacts from adjacent comment merge
    r = r.replace(/wp:wp:paragraph/gi, "wp:paragraph");
    // Fourth pass: remove orphaned block closers that have no matching opener
    {
      const openRe = /<!--\s*(wp:[\w-]+)(?:\s[^>]*)?\s*-->/g;
      const closeRe = /<!--\s*\/(wp:[\w-]+)\s*-->/g;
      const tokens: Array<{ type: string; kind: "open" | "close"; index: number }> = [];
      let m: RegExpExecArray | null;
      while ((m = openRe.exec(r)) !== null) {
        if (m[0].includes("/-->")) continue;
        tokens.push({ type: m[1], kind: "open", index: m.index });
      }
      while ((m = closeRe.exec(r)) !== null) {
        tokens.push({ type: m[1], kind: "close", index: m.index });
      }
      tokens.sort((a, b) => a.index - b.index);
      const stack: Array<{ type: string; index: number }> = [];
      for (const t of tokens) {
        if (t.kind === "open") {
          stack.push({ type: t.type, index: t.index });
        } else {
          const prev = stack.pop();
          if (!prev || prev.type !== t.type) {
            // Orphaned close — remove it
            const endIdx = r.indexOf("-->", t.index) + 3;
            r = r.substring(0, t.index) + r.substring(endIdx);
            if (prev) stack.push(prev); // restore the opener
          }
        }
      }
    }
    return r;
  };
  if (detectNestedParagraphs(state.blog) > 0) {
    console.log(`[PIPELINE:${stageName}] Detected nested <p> — flattening`);
    const flat = fp(state.blog);
    if (detectNestedParagraphs(flat) === 0) {
      state.blog = flat;
      state.articleDoc = parseArticleDocumentFromHtml(flat, state.articleDoc).doc!;
      console.log(`[PIPELINE:${stageName}] Flattened nested <p> successfully`);
    }
  }
  // Always apply the cleanup passes to remove orphaned/consecutive markers
  const cleaned = fp(state.blog);
  if (cleaned !== state.blog) {
    state.blog = cleaned;
    const pr = parseArticleDocumentFromHtml(cleaned, state.articleDoc);
    if (pr.doc) state.articleDoc = pr.doc;
  }

  const preHtml = state.blog;
  const inputFp = fp(preHtml);
  const stageBaseline = createArticleIntegrityBaseline(preHtml);
  const snap = preSnapshot ?? snapshotState(state);

  assertValidStageInput(preHtml, stageBaseline, stageName);

  const resultHtml = fn(state.blog);

  // Parse back to ArticleDocument. If parsing fails, restore snapshot.
  if (!applyHtmlToDocument(state, resultHtml, state.articleDoc)) {
    console.warn(`[PIPELINE:${stageName}] HTML-to-document parse failed — restoring pre-stage state`);
    restoreSnapshot(state, snap);
    recordStage(state, stageName, inputFp, inputFp, false, "parse-failure");
    return state;
  }

  const guard = guardStageOutput(state.blog, preHtml, stageBaseline, stageName);
  if (!guard.accepted) {
    restoreSnapshot(state, snap);
  } else {
    state.blog = guard.html;
  }
  const outputFp = fp(state.blog);
  recordStage(state, stageName, inputFp, outputFp, guard.accepted, guard.accepted ? undefined : "pre-stage-restore");
  return state;
}

// ── Pipeline state factory ──

export function createPipelineState(params: {
  userId: string; projectId: string; keyphrase: string; requestedWordCount: number;
  articleDoc: ArticleDocument; h2Headings: string[];
  intro: string; conclusion: string; wordsPerSection: number; exactKeyphraseTarget: number;
  policy: FinalArticlePolicy; ctx: any; wordMin: number; wordMax: number;
  systemPrompt: string; userMessage: string;
  retryCount?: number; componentRegenerations?: number;
}): PipelineState {
  const blog = renderArticleDocument(params.articleDoc);
  const initialFaq = params.articleDoc.visibleFaq.map((e) => ({
    question: e.question,
    answer: e.answerText,
  }));
  return {
    userId: params.userId, projectId: params.projectId, keyphrase: params.keyphrase,
    requestedWordCount: params.requestedWordCount, blog,
    title: params.articleDoc.metadata.title, slug: params.articleDoc.metadata.slug,
    metaDescription: params.articleDoc.metadata.metaDescription, excerpt: params.articleDoc.metadata.excerpt,
    faq: initialFaq, internalLinks: [], externalLinks: [], categories: [], tags: [], readingTime: "", summary: "",
    articleDoc: params.articleDoc, stageOutputs: [],
    h2Headings: params.h2Headings,
    intro: params.intro, conclusion: params.conclusion,
    wordsPerSection: params.wordsPerSection, exactKeyphraseTarget: params.exactKeyphraseTarget,
    retryCount: params.retryCount ?? 0, componentRegenerations: params.componentRegenerations ?? 0,
    warnings: [], startTime: Date.now(),
    normalizationResult: null, normalizationAccepted: false, qualityReport: null,
    policy: params.policy, ctx: params.ctx, baseline: null,
    wordMin: params.wordMin, wordMax: params.wordMax,
    estimatedTokens: 0, systemPrompt: params.systemPrompt, userMessage: params.userMessage,
    currentWordCount: 0, expansionAttempts: 0, trimAttempts: 0,
  };
}

export function validatePipelineOrder(state: PipelineState): Array<{ code: string; message: string; stage: string }> {
  const issues: Array<{ code: string; message: string; stage: string }> = [];
  const stages = state.stageOutputs.map((s) => s.stage);
  const required = ["expansion", "paragraphs", "regeneration", "external-links", "internal-links", "cta-preserve", "factual-scan", "link-enforce", "seo-normalization", "faq-recovery", "paragraphs-final", "final-validation"];
  for (const req of required) {
    if (!stages.includes(req)) issues.push({ code: "MISSING_STAGE", message: `Required stage "${req}" not found`, stage: req });
  }
  const intIdx = stages.indexOf("internal-links");
  const seoIdx = stages.indexOf("seo-normalization");
  if (intIdx >= 0 && seoIdx >= 0 && intIdx > seoIdx) {
    issues.push({ code: "STAGE_ORDER", message: "internal-links must run before seo-normalization", stage: "internal-links" });
  }
  return issues;
}

// ── Post-assembly pipeline ──

export async function runPostAssemblyPipeline(
  state: PipelineState,
  deps: PipelineDependencies,
): Promise<PipelineState> {
  state.baseline = createArticleIntegrityBaseline(state.blog);
  state.stageOutputs.push({ stage: "assembly", inputFingerprint: fp(state.blog), outputFingerprint: fp(state.blog), accepted: true });

  state = await runClaimCheck(state, deps);
  state = await runExpansion(state, deps);
  state = await runTrim(state, deps);

  // Paragraph normalization: HTML-returning, must parse back
  state = runTrackedHtmlStage(state, "paragraphs", (html) => {
    return normalizeParagraphs(html, MAX_SENTENCES_PER_PARAGRAPH).html;
  });

  state = await runRegeneration(state, deps);

  // Language switcher: HTML-returning
  state = runTrackedHtmlStage(state, "language-switcher", (html) => {
    const slugs = pairedSlugs(state.slug || "blog-post");
    const lsHtml = `<!-- wp:html --><div class="b2i-language-switcher" data-language="en"><span>English</span> | <a href="/blog/${slugs.chineseSlug}">繁體中文</a></div><!-- /wp:html -->`;
    return /b2i-language-switcher/i.test(html) ? html : lsHtml + "\n\n" + html;
  });

  // External links: HTML-returning
  state = runTrackedHtmlStage(state, "external-links", (html) => {
    const researchItems = deps.context?.research || [];
    if (researchItems.length === 0) return html;
    return insertExternalResearchLinks(html, researchItems, 3).html;
  });

  // External dedup: HTML-returning
  state = runTrackedHtmlStage(state, "external-dedup", (html) => {
    return deduplicateEditorialExternalLinks(html).html;
  });

  state = await runInternalLinks(state, deps);
  state = await runSeoNormalization(state, deps);

  // Title repair: non-HTML mutation (title only)
  // Uses one AI retry maximum, then deterministic fallback.
  // Titles 40–49 characters are accepted with a soft warning (not a 500 error).
  state = runTrackedHtmlStage(state, "title-repair", (html) => {
    const titleOk = state.title.length >= 40 && state.title.length <= 70 && containsExactPhrase(state.title, state.keyphrase);
    if (titleOk) return html;
    
    // One deterministic attempt: prepend keyphrase if missing and within length
    if (!containsExactPhrase(state.title, state.keyphrase)) {
      const titlePhrase = state.keyphrase.charAt(0).toUpperCase() + state.keyphrase.slice(1);
      const candidate = `${titlePhrase}: ${state.title}`;
      if (candidate.length >= 40 && candidate.length <= 70) {
        state.title = candidate;
        console.log(`[title-repair] deterministic prepend: "${state.title}"`);
        return html;
      }
      // Try shorter suffix format
      const shortCandidate = `${titlePhrase}: What You Need to Know`;
      if (shortCandidate.length >= 40 && shortCandidate.length <= 70) {
        state.title = shortCandidate;
        console.log(`[title-repair] deterministic suffix: "${state.title}"`);
        return html;
      }
    }
    
    // Accept 40-49 as soft warning (don't throw, don't loop)
    if (state.title.length >= 40 && state.title.length < 50) {
      console.log(`[title-repair] soft-warning: title length ${state.title.length} accepted`);
      return html;
    }
    
    console.log(`[title-repair] no fix applied — title="${state.title}" len=${state.title.length}`);
    return html;
  });

  // Paragraph normalization moved to after faq-recovery (after all stages
  // that modify section bodies). See paragraphs-final stage below.

  // Factual-risk scan and repair: HTML-returning
  state = runTrackedHtmlStage(state, "factual-scan", (html) => {
    const research = deps.context?.research || [];
    const risk = scanFactualRisks(html, state.keyphrase, research);
    console.log(`[factual-scan] ${formatClaimLog(risk.claims)}`);
    
    if (risk.hasHighRisk) {
      const unsupported = risk.claims.filter((c: any) => !c.supported);
      // Group unsupported claims by section index
      const bySection = new Map<number, typeof unsupported>();
      for (const c of unsupported) {
        if (!bySection.has(c.sectionIndex)) bySection.set(c.sectionIndex, []);
        bySection.get(c.sectionIndex)!.push(c);
      }
      
      // Attempt targeted repair for each affected section
      for (const [sectionIdx, sectionClaims] of bySection) {
        const section = state.articleDoc.sections[sectionIdx];
        if (!section || section.status === "missing") continue;

        // Remove unsupported sentences from the section
        const sectionHtml = renderComponentHtml(section);
        const { html: cleanedHtml, sentencesRemoved } = removeUnsupportedSentences(sectionHtml, sectionClaims);
        if (sentencesRemoved > 0 && cleanedHtml.length > 50) {
          console.log(`[factual-scan] section=${sectionIdx} removed ${sentencesRemoved} unsupported sentence(s)`);
          const { blocks } = parseWordPressEditorialBlocks(cleanedHtml, `section-${sectionIdx}`);
          if (blocks.length > 0) {
            state.articleDoc.sections[sectionIdx].blocks = blocks;
          }
          state.articleDoc.sections[sectionIdx].status = "normalized";
        }
      }
      syncBlogFromDocument(state);
    }
    return state.blog;
  });

  // Internal-link limit enforcement: HTML-returning
  state = runTrackedHtmlStage(state, "link-enforce", (html) => {
    const result = enforceInternalLinkLimit(html, 4);
    console.log(`[link-enforce] retained=${result.retained.length} removed=${result.removed.length}`);
    return result.html;
  });

  // Deterministic final trim: HTML-returning
  // Removes repetition, filler and redundant examples from editable sections
  // while preserving headings, FAQ, conclusion, CTA, sourced claims, links, and protected blocks.
  // Runs after all editorial link enforcement but BEFORE FAQ recovery (which adds schema).
  state = runTrackedHtmlStage(state, "final-trim", (html) => {
    const currentWc = countReadableWords(html);
    if (currentWc <= state.wordMax) {
      console.log(`[final-trim] skipped (wc=${currentWc} <= ${state.wordMax})`);
      return html;
    }
    
    // Process sections in rounds until under limit
    const excess = currentWc - state.wordMax;
    let totalRemoved = 0;
    const maxPasses = Math.min(8, Math.ceil(excess / 100) + 1);
    for (let pass = 0; pass < maxPasses; pass++) {
      const currentWcNow = countReadableWords(state.blog);
      if (currentWcNow <= state.wordMax) break;
      const stillExcess = currentWcNow - state.wordMax;
      const targetPerPass = Math.max(30, Math.ceil(stillExcess / Math.max(1, state.articleDoc.sections.length)));
      let passRemoved = 0;
      for (let i = 0; i < state.articleDoc.sections.length; i++) {
        if (passRemoved >= targetPerPass * 1.5) break;
        const section = state.articleDoc.sections[i];
        const sectionHtml = renderComponentHtml(section);
        if (!sectionHtml || sectionHtml.length < 100) continue;
        if (/faq|frequently.asked/i.test(section.heading)) continue;
        const sectionWc = countReadableWords(sectionHtml);
        if (sectionWc < 80) continue;
        const paraBlocks = sectionHtml.match(
          /<!--\s*wp:paragraph\s*-->\s*\n?<p>[\s\S]*?<\/p>\s*\n?<!--\s*\/wp:paragraph\s*-->/gi,
        );
        if (!paraBlocks || paraBlocks.length <= 1) continue;
        const lastPara = paraBlocks[paraBlocks.length - 1];
        const lastParaWc = countReadableWords(lastPara);
        if (lastParaWc < 10) continue;
        if (/<a\b/i.test(lastPara) || /\d+\s*(?:%|percent|times)/i.test(lastPara)) continue;
        const lastIdx = sectionHtml.lastIndexOf(lastPara);
        if (lastIdx < 0) continue;
        const trimmedHtml = sectionHtml.substring(0, lastIdx).trim() + sectionHtml.substring(lastIdx + lastPara.length);
        const { blocks: trimmedBlocks } = parseWordPressEditorialBlocks(trimmedHtml, `section-${i}`);
        if (trimmedBlocks.length > 0) {
          state.articleDoc.sections[i].blocks = trimmedBlocks;
        }
        state.articleDoc.sections[i].status = "trimmed";
        totalRemoved += lastParaWc;
        passRemoved += lastParaWc;
        console.log(`[final-trim] pass=${pass} section=${i} removed ${lastParaWc} words`);
      }
      if (passRemoved === 0) break;
    }
    
    if (totalRemoved > 0) {
      syncBlogFromDocument(state);
      const finalWc = countReadableWords(state.blog);
      console.log(`[final-trim] total removed=${totalRemoved} final wc=${finalWc} target=${state.wordMax}`);
    } else {
      console.log(`[final-trim] no paragraphs removed — excess=${excess}`);
    }
    return state.blog;
  });

  // FAQ recovery: uses state.articleDoc.visibleFaq (canonical source).
  // After all content-changing stages, ensures visible FAQ is rendered and the
  // FAQPage JSON-LD schema matches exactly. Rebuilds if questions or answers differ.
  state = runTrackedHtmlStage(state, "faq-recovery", (html) => {
    const existingFaqBlock = extractFaqBlockForPipeline(html);
    const visibleFaq = state.articleDoc.visibleFaq;

    if (visibleFaq.length === 0) {
      // Fallback: try to extract FAQ from the rendered HTML. This handles
      // edge cases where the AI format didn't match the initial extractor.
      const extractedHtml = extractVisibleFaqFromArticle(html);
      if (extractedHtml.length > 0) {
        console.log(`[faq-recovery] Fallback: extracted ${extractedHtml.length} FAQ entries from HTML`);
        state.articleDoc.visibleFaq = extractedHtml.map((e) => ({
          question: e.question,
          answerHtml: "",
          answerText: e.answerText,
        }));
        syncBlogFromDocument(state);
        return state.blog;
      }
      console.log(`[faq-recovery] No visible FAQ in doc — skipping`);
      return html;
    }

    let needsRebuild = false;
    if (existingFaqBlock) {
      // Use full parity validation
      const parityResult = validateFaqParity(
        visibleFaq.map((v) => ({ question: v.question, answerHtml: "", answerText: v.answerText })),
        existingFaqBlock,
      );
      if (parityResult.valid) {
        console.log(`[faq-recovery] FAQ parity valid (${visibleFaq.length} entries) — skipping`);
        return html;
      }
      console.log(`[faq-recovery] FAQ parity mismatch: ${parityResult.issues.map((i) => i.detail).join("; ")} — rebuilding`);
      needsRebuild = true;
    } else {
      console.log(`[faq-recovery] No existing FAQ schema found — building`);
      needsRebuild = true;
    }

    if (needsRebuild) {
      console.log(`[faq-recovery] Rebuilding article from ${visibleFaq.length} visible FAQ entries`);
      syncBlogFromDocument(state);
    }
    return state.blog;
  });

  // Paragraph normalization — LAST content-changing stage before CTA and validation.
  // Runs after factorial-scan, final-trim, and faq-recovery so no later
  // syncBlogFromDocument() can rejoin split paragraphs.
  state = runTrackedHtmlStage(state, "paragraphs-final", (html) => {
    const result = normalizeParagraphs(html, MAX_SENTENCES_PER_PARAGRAPH);
    return result.html;
  });

  // CTA preservation: runs after ALL content-changing stages and FAQ recovery.
  // Ensures exactly one CTA block with one CTA heading and one signup URL.
  // If the CTA is missing or damaged, sets it on the canonical ArticleDocument
  // and re-renders — avoiding fragile HTML string surgery that can break WP blocks.
  state = runTrackedHtmlStage(state, "cta-preserve", (html) => {
    const signupCount = (html.match(/app\.b2ihub\.com\/signup/gi) ?? []).length;
    const headingCount = countCtaHeadingTags(html);
    const ctaOk = signupCount === 1 && headingCount >= 1;
    if (ctaOk) return html;

    console.log(`[cta-preserve] CTA check failed: signup=${signupCount} headings=${headingCount} — re-injecting`);

    // Strip any existing signup blocks to avoid duplicates
    let result = html.replace(/<!--\s*wp:html\s*-->[\s\S]*?app\.b2ihub\.com\/signup[\s\S]*?<!--\s*\/wp:html\s*-->/gi, "");
    // Append canonical CTA at the end
    result = result.trim() + "\n\n" + CANONICAL_CTA_HTML;

    state.articleDoc.cta = { id: "cta", type: "cta", html: CANONICAL_CTA_HTML, fingerprint: fingerprintHtml(CANONICAL_CTA_HTML) };
    // Parse back so articleDoc stays in sync with the HTML
    const parsed = parseArticleDocumentFromHtml(result, state.articleDoc);
    if (parsed.doc) state.articleDoc = parsed.doc;
    return result;
  });

  // Final word count check — trim one last time if over limit
  state = runTrackedHtmlStage(state, "wc-check", (html) => {
    const wc = countReadableWords(html);
    if (wc <= state.wordMax) return html;
    console.log(`[wc-check] word count ${wc} exceeds ${state.wordMax} — trimming FAQ`);
    const ok = trimFaqDirectly(state);
    if (!ok) {
      console.log(`[wc-check] at minimum FAQ count still over limit — hard failing`);
    }
    console.log(`[wc-check] after trim: wc=${countReadableWords(state.blog)}`);
    return state.blog;
  });

  // Final validation
  state = runTrackedHtmlStage(state, "final-validation", (html) => {
    const result = runFinalValidation(state);
    if (!result.passed) throw new Error(`Final validation failed: ${result.reasons.join("; ")}`);
    return html;
  });

  const orderIssues = validatePipelineOrder(state);
  if (orderIssues.length > 0) console.warn(`[PIPELINE] Order issues: ${orderIssues.map((i) => i.message).join("; ")}`);

  return state;
}

// ── Stage implementations ──

async function runClaimCheck(state: PipelineState, deps: PipelineDependencies): Promise<PipelineState> {
  const sections = state.articleDoc.sections;
  const bodies = sections.map((s, i) => ({ index: i, body: renderComponentHtml(s) }));
  const conflicts = detectClaimConflicts(bodies, { claims: [] });
  if (conflicts.length === 0) {
    const fpSnap = fp(state.blog);
    recordStage(state, "claim-check", fpSnap, fpSnap, true, undefined, { skipped: true, reason: "no-conflicts" });
    return state;
  }

  const preHtml = state.blog;
  const snap = snapshotState(state);
  for (const c of conflicts) {
    const section = sections[c.sectionIndexB];
    if (!section) continue;
    try {
      const prevHeading = c.sectionIndexB > 0 ? state.h2Headings[c.sectionIndexB - 1] : "none";
      const nextHeading = c.sectionIndexB < state.h2Headings.length - 1 ? state.h2Headings[c.sectionIndexB + 1] : "none";
      const regeneratedBody = await regenerateSection(
        { chatWithRetry: deps.makeTrackedChatForStage("claim_fix"), promptContext: deps.context } as any,
        state.title, section.heading, prevHeading, nextHeading, state.wordsPerSection, state.exactKeyphraseTarget, state.keyphrase,
      );
      if (regeneratedBody && countReadableWords(regeneratedBody) > 0) {
        const { blocks: rb } = parseWordPressEditorialBlocks(regeneratedBody, `section-${c.sectionIndexB}`);
        if (rb.length > 0) {
          state.articleDoc.sections[c.sectionIndexB].blocks = rb;
        }
        state.articleDoc.sections[c.sectionIndexB].status = "regenerated";
        syncBlogFromDocument(state);
      }
    } catch (err) { /* continue */ }
  }
  return runTrackedHtmlStage(state, "claim-check", (html) => html, snap);
}

async function runExpansion(state: PipelineState, deps: PipelineDependencies): Promise<PipelineState> {
  state.currentWordCount = countReadableWords(state.blog);
  if (state.currentWordCount >= state.wordMin) {
    const fpSnap = fp(state.blog);
    recordStage(state, "expansion", fpSnap, fpSnap, true, undefined, { skipped: true, reason: "already-in-range" });
    return state;
  }

  const snap = snapshotState(state);
  const sectionsInput = deriveSectionInput(state);
  const result = await expandToMinimum({ chatWithRetry: deps.chatWithRetry }, sectionsInput.map((s) => ({ ...s })), sectionsInput, state.intro, state.conclusion, state.currentWordCount, state.wordMin, state.wordsPerSection);

  for (const s of result.sections) {
    if (s.index >= 0 && s.index < state.articleDoc.sections.length) {
      const { blocks: sb } = parseWordPressEditorialBlocks(s.body, `section-${s.index}`);
      if (sb.length > 0) {
        state.articleDoc.sections[s.index].blocks = sb;
      }
      state.articleDoc.sections[s.index].status = "expanded";
    }
  }
  state.currentWordCount = result.finalWordCount;
  state.expansionAttempts = result.expansions;
  syncBlogFromDocument(state);

  return runTrackedHtmlStage(state, "expansion", (html) => html, snap);
}

async function runTrim(state: PipelineState, deps: PipelineDependencies): Promise<PipelineState> {
  if (state.currentWordCount <= state.wordMax) {
    const fpSnap = fp(state.blog);
    recordStage(state, "trim", fpSnap, fpSnap, true, undefined, { skipped: true, reason: "already-in-range" });
    return state;
  }

  const snap = snapshotState(state);
  const sectionsInput = deriveSectionInput(state);
  const result = await trimToMaximum({ chatWithRetry: deps.chatWithRetry }, sectionsInput.map((s) => ({ ...s })), state.intro, state.conclusion, state.currentWordCount, state.wordMax);

  for (const s of result.sections) {
    if (s.index >= 0 && s.index < state.articleDoc.sections.length) {
      const { blocks: tb } = parseWordPressEditorialBlocks(s.body, `section-${s.index}`);
      if (tb.length > 0) {
        state.articleDoc.sections[s.index].blocks = tb;
      }
    }
  }
  state.currentWordCount = result.finalWordCount;
  state.trimAttempts = result.trims;
  syncBlogFromDocument(state);

  return runTrackedHtmlStage(state, "trim", (html) => html, snap);
}

async function runRegeneration(state: PipelineState, deps: PipelineDependencies): Promise<PipelineState> {
  const snap = snapshotState(state);
  const genCtx: any = { chatWithRetry: deps.chatWithRetry, promptContext: deps.context };
  const { blog: regeneratedBlog, title: regeneratedTitle, meta: regeneratedMeta } = await runComponentRegeneration(
    genCtx, { title: state.title, metaDescription: state.metaDescription, blog: state.blog },
    state.h2Headings, state.keyphrase,
    { intro: state.wordsPerSection, conclusion: state.wordsPerSection, perSection: state.wordsPerSection, keyphraseTarget: state.exactKeyphraseTarget },
  );
  state.title = regeneratedTitle;
  state.metaDescription = regeneratedMeta;

  return runTrackedHtmlStage(state, "regeneration", (html) => regeneratedBlog, snap);
}

async function runInternalLinks(state: PipelineState, deps: PipelineDependencies): Promise<PipelineState> {
  const snap = snapshotState(state);
  try {
    const { seedDefaultLinks } = await import("@/lib/services/default-links");
    const { injectLinks } = await import("@/lib/services/link-injector");
    await seedDefaultLinks(state.userId);
    const result = await injectLinks(state.blog, state.userId);
    if (result.linksInjected > 0) {
      return runTrackedHtmlStage(state, "internal-links", (html) => result.modifiedContent, snap);
    }
  } catch (err) {
    // Non-fatal
  }
  const preHtml = state.blog;
  const inputFp = fp(preHtml);
  recordStage(state, "internal-links", inputFp, inputFp, true, undefined, { skipped: true, reason: "no-links-to-inject" });
  return state;
}

async function runSeoNormalization(state: PipelineState, deps: PipelineDependencies): Promise<PipelineState> {
  const snap = snapshotState(state);
  try {
    const result = await normalizeFinalSeo(
      { html: state.blog, focusKeyphrase: state.keyphrase, targetWordCount: state.requestedWordCount, targetKeyphraseCount: state.exactKeyphraseTarget, minReadingEase: 60, maxReadingEase: 80 },
      deps.chatWithRetry as any,
    );
    const safety = result.safety;
    const ctaOk = state.articleDoc.cta !== null;
    const accepted = result.passed === true && safety.protectedBlocksUnchanged && safety.linkDestinationsUnchanged && safety.wordpressBlocksValid && safety.faqSchemaPreserved && safety.languageSwitcherPreserved && ctaOk;
    state.normalizationResult = result;
    state.normalizationAccepted = accepted;

    if (accepted) {
      return runTrackedHtmlStage(state, "seo-normalization", (html) => result.html, snap);
    }
  } catch {
    state.normalizationResult = null;
    state.normalizationAccepted = false;
  }
  const preHtml = state.blog;
  const inputFp = fp(preHtml);
  recordStage(state, "seo-normalization", inputFp, inputFp, true, undefined, { skipped: true, reason: "normalization-rejected-or-failed" });
  return state;
}

export function runFinalValidation(state: PipelineState): { passed: boolean; reasons: string[] } {
  const metrics = analyzeFinalArticle(state.blog, state.keyphrase, state.title, state.metaDescription);
  const policy = buildPolicy(state.requestedWordCount, state.wordMin, state.wordMax, state.keyphrase);
  const result = evaluatePolicy(metrics, policy);
  return { passed: result.passed, reasons: result.reasons };
}
